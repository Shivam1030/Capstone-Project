# Run Student Insight in VS Code

## Requirements

- Node.js **22.13.x**
- npm **10.9.2**
- VS Code

Check the installed versions in the VS Code terminal:

```sh
node --version
npm --version
```

## Start the development website

1. Download and extract the source ZIP.
2. In VS Code, choose **File → Open Folder…** and select the extracted folder that contains `package.json`.
3. Choose **Terminal → New Terminal**.
4. Install the locked project dependencies and start the app:

```sh
npm ci
npm run dev
```

5. Open **http://localhost:3000** in your browser. The Express server starts Vite for the frontend and serves the same-origin API. You do not need to run a second server command.
6. Press **Ctrl+C** in the terminal to stop the server.

## Create a production build locally

```sh
npm run build
```

To serve that build locally, set `NODE_ENV=production` and then run `npm start`:

**Windows PowerShell**

```powershell
$env:NODE_ENV = "production"
$env:PORT = "3000"
npm start
```

**macOS/Linux**

```sh
NODE_ENV=production PORT=3000 npm start
```

## Chatbot credentials

The student dashboard, records, local CSV import, model evaluation, and exports can run without AI credentials. For AI chat in a standalone local environment, the server needs an OpenAI-compatible endpoint and a key, provided as environment variables **in the same terminal before starting the server**:

**Windows PowerShell**

```powershell
$env:MANUS_API_URL = "YOUR_COMPATIBLE_API_BASE_URL"
$env:MANUS_API_KEY = "YOUR_API_KEY"
npm run dev
```

**macOS/Linux**

```sh
export MANUS_API_URL="YOUR_COMPATIBLE_API_BASE_URL"
export MANUS_API_KEY="YOUR_API_KEY"
npm run dev
```

The endpoint base URL should support `POST /v1/chat/completions`. Do not place real keys in source code, screenshots, or Git commits. The hosted Manus Preview supplies its AI service configuration; those private credentials are **not** included in this ZIP. Without local credentials, the chatbot reports that the AI service is unavailable, while the rest of the dashboard remains usable.

## Data location

Student records and imported training CSV data are stored in that browser's local storage. A localhost browser has separate data from the hosted Preview and from other browsers/devices. The app's sample training cohort is synthetic; import labeled historical CSV data before interpreting the evaluation metrics as institution-specific.
