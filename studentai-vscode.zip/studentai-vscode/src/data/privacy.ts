import type { Student } from './students';

function escapeRegex(value: string) { return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function normalizeWord(value: string) {
  return value.replace(/['’]s$/i, '').normalize('NFKD').replace(/\p{M}/gu, '').toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
}

function withinOneEdit(left: string, right: string) {
  const a = Array.from(left); const b = Array.from(right);
  if (Math.abs(a.length - b.length) > 1) return false;
  if (a.length === b.length) {
    const mismatches = a.flatMap((char, index) => char === b[index] ? [] : [index]);
    if (mismatches.length === 2 && a[mismatches[0]] === b[mismatches[1]] && a[mismatches[1]] === b[mismatches[0]]) return true;
    return mismatches.length <= 1;
  }
  let i = 0; let j = 0; let edits = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) { i++; j++; continue; }
    if (++edits > 1) return false;
    if (a.length > b.length) i++;
    else j++;
  }
  return edits + Math.max(a.length - i, b.length - j) <= 1;
}

function likelyNameMention(word: string, prefix: string) {
  const clean = word.replace(/['’]s$/i, '');
  const titleCase = /^\p{Lu}\p{Ll}{2,}$/u.test(clean);
  const explicitCue = /\b(?:student|learner|classmate|person|named|called|name|mr|mrs|ms|dr)\s*$/iu.test(prefix);
  const sentenceStart = !prefix.trim() || /[.!?]\s*$/u.test(prefix);
  const possessive = /['’]s$/iu.test(word);
  return explicitCue || (titleCase && (!sentenceStart || possessive));
}

/** Remove roster identifiers in the browser before a chat message reaches the AI server. */
export function redactKnownStudentData(text: string, students: Student[]) {
  const privateValues = students.flatMap((student) => [student.email, student.phone, student.id]).filter((value) => value && value.trim().length > 1).sort((a, b) => b.length - a.length);
  const fullNames = students.map((student) => student.name.trim()).filter(Boolean).sort((a, b) => b.length - a.length);
  let safe = text;
  for (const value of privateValues) safe = safe.replace(new RegExp(escapeRegex(value), 'gi'), '[redacted student detail]');
  safe = safe.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[redacted email]')
    .replace(/\bST[-_ ]?\d{3,}\b/gi, '[redacted student ID]')
    .replace(/\+?\d[\d\s().-]{5,}\d/g, '[redacted phone]');

  for (const name of fullNames) {
    const namePattern = new RegExp(`(^|[^\\p{L}\\p{N}])(${escapeRegex(name)})(?=$|[^\\p{L}\\p{N}])`, 'giu');
    safe = safe.replace(namePattern, (_match, prefix: string) => `${prefix}[redacted student name]`);
  }

  const exactTokens = new Set<string>();
  const fuzzyTokens = new Set<string>();
  for (const name of fullNames) {
    const compact = normalizeWord(name);
    if (compact.length >= 6) exactTokens.add(compact);
    if (compact.length >= 6) fuzzyTokens.add(compact);
    for (const part of name.split(/[\s\-–—'’]+/u).filter(Boolean)) {
      const token = normalizeWord(part);
      if (token.length >= 3) exactTokens.add(token);
      if (token.length >= 6) fuzzyTokens.add(token);
    }
  }
  const rosterNames = [...exactTokens];
  const nearNames = [...fuzzyTokens];
  return safe.replace(/[\p{L}\p{M}\p{N}][\p{L}\p{M}\p{N}'’\-]*/gu, (word, offset: number, source: string) => {
    const token = normalizeWord(word);
    const isExact = rosterNames.includes(token);
    const prefix = source.slice(0, offset);
    const isLikelyVariant = !isExact && token.length >= 6 && likelyNameMention(word, prefix)
      && nearNames.some((name) => name.length >= 6 && withinOneEdit(token, name));
    return isExact || isLikelyVariant ? '[redacted student name]' : word;
  });
}
