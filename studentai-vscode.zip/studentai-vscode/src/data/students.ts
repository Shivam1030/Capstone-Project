export type Student = {
  id: string;
  name: string;
  email: string;
  phone: string;
  attendance: number;
  marks: number;
  internalMarks: number;
  assignmentScore: number;
  practicalScore: number;
  previousSemester: number;
  studyHours: number;
  participation: number;
  course: string;
  year: string;
  updatedAt: string;
};

export type Prediction = {
  score: number;
  label: 'High-performing' | 'Average-performing' | 'At-risk';
  note: string;
  modelName?: string;
};

const now = new Date().toISOString();
const sampleRows = [
  { id: 'ST-2401', name: 'Amara Okafor', email: 'amara.okafor@example.edu', phone: '+1 (415) 555-0142', attendance: 96, marks: 92, course: 'Computer Science', year: 'Year 3' },
  { id: 'ST-2402', name: 'Theo Bennett', email: 'theo.bennett@example.edu', phone: '+1 (415) 555-0178', attendance: 91, marks: 85, course: 'Applied Mathematics', year: 'Year 2' },
  { id: 'ST-2403', name: 'Priya Nair', email: 'priya.nair@example.edu', phone: '+1 (415) 555-0129', attendance: 98, marks: 96, course: 'Data Science', year: 'Year 4' },
  { id: 'ST-2404', name: 'Luca Moretti', email: 'luca.moretti@example.edu', phone: '+1 (415) 555-0163', attendance: 77, marks: 72, course: 'Computer Science', year: 'Year 3' },
  { id: 'ST-2405', name: 'Mei Chen', email: 'mei.chen@example.edu', phone: '+1 (415) 555-0191', attendance: 88, marks: 89, course: 'Design & Technology', year: 'Year 2' },
  { id: 'ST-2406', name: 'Jordan Williams', email: 'jordan.williams@example.edu', phone: '+1 (415) 555-0108', attendance: 69, marks: 61, course: 'Applied Mathematics', year: 'Year 1' },
  { id: 'ST-2407', name: 'Sofia Andersson', email: 'sofia.andersson@example.edu', phone: '+1 (415) 555-0187', attendance: 94, marks: 90, course: 'Data Science', year: 'Year 4' },
  { id: 'ST-2408', name: 'Ethan Brooks', email: 'ethan.brooks@example.edu', phone: '+1 (415) 555-0113', attendance: 82, marks: 78, course: 'Computer Science', year: 'Year 2' },
  { id: 'ST-2409', name: 'Aisha Rahman', email: 'aisha.rahman@example.edu', phone: '+1 (415) 555-0154', attendance: 73, marks: 68, course: 'Design & Technology', year: 'Year 3' },
  { id: 'ST-2410', name: 'Noah Kim', email: 'noah.kim@example.edu', phone: '+1 (415) 555-0198', attendance: 90, marks: 82, course: 'Applied Mathematics', year: 'Year 1' },
  { id: 'ST-2411', name: 'Isabella Garcia', email: 'isabella.garcia@example.edu', phone: '+1 (415) 555-0136', attendance: 86, marks: 87, course: 'Data Science', year: 'Year 3' },
  { id: 'ST-2412', name: 'Arjun Patel', email: 'arjun.patel@example.edu', phone: '+1 (415) 555-0105', attendance: 64, marks: 57, course: 'Computer Science', year: 'Year 1' },
];
export const starterStudents: Student[] = sampleRows.map((student, index) => ({
  ...student, internalMarks: student.marks, assignmentScore: Math.min(100, student.marks + (index % 4)),
  practicalScore: Math.max(0, student.marks - (index % 3)), previousSemester: Math.max(0, student.marks - 3 + (index % 5)),
  studyHours: 7 + (index * 3 % 18), participation: Math.max(20, Math.min(100, student.attendance - 5 + (index % 9))), updatedAt: now,
}));

export const STORAGE_KEY = 'student-insight-records-v1';
const bounded = (value: unknown, fallback: number, max: number) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= max ? value : fallback;

function migrateStudent(value: unknown): Student | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const requiredText = ['id', 'name', 'email', 'phone', 'course', 'year'];
  if (!requiredText.every((key) => typeof record[key] === 'string' && (record[key] as string).trim().length > 0)) return null;
  const attendance = bounded(record.attendance, -1, 100);
  const marks = bounded(record.marks, -1, 100);
  if (attendance < 0 || marks < 0) return null;
  const email = String(record.email); const phone = String(record.phone);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || phone.replace(/\D/g, '').length < 7) return null;
  const optionalFields: Pick<Student, 'internalMarks' | 'assignmentScore' | 'practicalScore' | 'previousSemester' | 'studyHours' | 'participation'> = {
    internalMarks: bounded(record.internalMarks, marks, 100), assignmentScore: bounded(record.assignmentScore, marks, 100),
    practicalScore: bounded(record.practicalScore, marks, 100), previousSemester: bounded(record.previousSemester, marks, 100),
    studyHours: bounded(record.studyHours, 12, 40), participation: bounded(record.participation, attendance, 100),
  };
  const invalidProvidedField = Object.entries(optionalFields).some(([key]) => record[key] !== undefined && typeof record[key] !== 'number');
  if (invalidProvidedField) return null;
  return {
    id: String(record.id), name: String(record.name).trim(), email, phone: phone.trim(), attendance, marks,
    internalMarks: optionalFields.internalMarks, assignmentScore: optionalFields.assignmentScore, practicalScore: optionalFields.practicalScore,
    previousSemester: optionalFields.previousSemester, studyHours: optionalFields.studyHours, participation: optionalFields.participation,
    course: String(record.course).trim(), year: String(record.year).trim(),
    updatedAt: typeof record.updatedAt === 'string' && record.updatedAt.trim() ? record.updatedAt : now,
  };
}

export function loadStudents(): Student[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return starterStudents;
    const parsed: unknown = JSON.parse(stored);
    if (Array.isArray(parsed)) {
      const validRecords = parsed.map(migrateStudent).filter((student): student is Student => student !== null);
      if (validRecords.length !== parsed.length) console.warn('Invalid saved student rows were discarded.');
      return validRecords;
    }
  } catch (error) { console.warn('Could not load saved student records.', error); }
  return starterStudents;
}

export function predict(student: Pick<Student, 'attendance' | 'marks'>): Prediction {
  const score = Math.round(student.marks * 0.65 + student.attendance * 0.35);
  const label: Prediction['label'] = score >= 80 ? 'High-performing' : score >= 58 ? 'Average-performing' : 'At-risk';
  const note = label === 'At-risk'
    ? `The student may benefit from a supportive check-in; attendance is ${student.attendance}%.`
    : `This is a directional signal from marks (${student.marks}%) and attendance (${student.attendance}%).`;
  return { score, label, note };
}

export function average(values: number[]): number { return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0; }
export function initials(name: string): string { return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase(); }
export function predictionTone(label: Prediction['label']): string {
  return label === 'High-performing' ? 'excellent' : label === 'Average-performing' ? 'on-track' : 'risk';
}
