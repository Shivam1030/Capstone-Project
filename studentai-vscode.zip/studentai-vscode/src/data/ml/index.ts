import type { Student } from '../students';

export const FEATURE_KEYS = ['attendance', 'marks', 'internalMarks', 'assignmentScore', 'practicalScore', 'previousSemester', 'studyHours', 'participation'] as const;
export const FEATURE_LABELS: Record<(typeof FEATURE_KEYS)[number], string> = {
  attendance: 'Attendance', marks: 'Current marks', internalMarks: 'Internal exams', assignmentScore: 'Assignments', practicalScore: 'Practical work',
  previousSemester: 'Previous semester', studyHours: 'Study hours', participation: 'Academic participation',
};
export const OUTCOMES = ['high-performing', 'average-performing', 'at-risk'] as const;
export type Outcome = (typeof OUTCOMES)[number];
export type AlgorithmId = 'linear-regression' | 'decision-tree' | 'random-forest' | 'logistic-regression' | 'svm';
export const ALGORITHMS: { id: AlgorithmId; name: string; kind: string; description: string }[] = [
  { id: 'linear-regression', name: 'Linear Regression', kind: 'Regression', description: 'Fits a continuous score; score bands provide the outcome class.' },
  { id: 'decision-tree', name: 'Decision Tree', kind: 'Classification', description: 'Readable threshold rules split academic factors into outcomes.' },
  { id: 'random-forest', name: 'Random Forest', kind: 'Ensemble', description: 'A vote across varied decision trees reduces reliance on one split.' },
  { id: 'logistic-regression', name: 'Logistic Regression', kind: 'Classification', description: 'Estimates the likelihood of each performance category.' },
  { id: 'svm', name: 'Support Vector Machine', kind: 'Classification', description: 'Finds separating margins between the performance classes.' },
];
export const TRAINING_STORAGE_KEY = 'student-insight-history-v1';
export type TrainingRow = { features: (number | null)[]; label: Outcome };
type CleanTrainingRow = { features: number[]; label: Outcome };
export type DatasetSource = 'synthetic' | 'uploaded';
export type ImportStats = { rowsRead: number; accepted: number; imputedCells: number; rejectedRows: number; duplicateRows: number; notes: string[] };
export type ModelMetrics = { id: AlgorithmId; name: string; accuracy: number; precision: number; recall: number; f1: number; mae: number; rmse: number; confusion: number[][]; importance: number[] };
export type FittedModel = { id: AlgorithmId; name: string; predict(features: number[]): { label: Outcome; score: number }; importance: number[] };
export type ModelRun = { rows: TrainingRow[]; source: DatasetSource; inputSource: DatasetSource; usedSyntheticFallback: boolean; evaluated: number; trainingCount: number; results: ModelMetrics[]; selected: FittedModel; selectedMetrics: ModelMetrics; error?: string };

const SCALE_DIVISORS = [100, 100, 100, 100, 100, 100, 40, 100];
const DEFAULT_FEATURES = [80, 75, 65, 65, 65, 65, 10, 50];
const classScore: Record<Outcome, number> = { 'high-performing': 91, 'average-performing': 69, 'at-risk': 44 };
export const OUTCOME_LABEL: Record<Outcome, 'High-performing' | 'Average-performing' | 'At-risk'> = { 'high-performing': 'High-performing', 'average-performing': 'Average-performing', 'at-risk': 'At-risk' };

export function vectorForStudent(student: Student): number[] {
  const values = [student.attendance, student.marks, student.internalMarks ?? student.marks, student.assignmentScore ?? student.marks, student.practicalScore ?? student.marks, student.previousSemester ?? student.marks, student.studyHours ?? 10, student.participation ?? student.attendance];
  return values.map((value, index) => clamp(Number.isFinite(value) ? value : DEFAULT_FEATURES[index], 0, index === 6 ? 40 : 100));
}

function scaled(features: number[]) { return features.map((value, index) => clamp((Number.isFinite(value) ? value : DEFAULT_FEATURES[index]) / SCALE_DIVISORS[index], 0, 1)); }
function clamp(value: number, min: number, max: number) { return Math.min(max, Math.max(min, value)); }
function scoreOutcome(value: number): Outcome { return value >= 80 ? 'high-performing' : value >= 58 ? 'average-performing' : 'at-risk'; }
function meanClassScore(rows: TrainingRow[]) { return rows.length ? rows.reduce((sum, row) => sum + classScore[row.label], 0) / rows.length : 65; }
function seededRandom(seed: number) { let state = seed >>> 0; return () => { state = (state * 1664525 + 1013904223) >>> 0; return state / 4294967296; }; }

export function createSyntheticHistory(count = 180): TrainingRow[] {
  const random = seededRandom(20261007);
  return Array.from({ length: count }, (_, index) => {
    const group = index % 3;
    const base = group === 0 ? 30 + random() * 17 : group === 1 ? 56 + random() * 14 : 78 + random() * 17;
    const jitter = (spread: number) => Math.round(base + (random() - 0.5) * spread);
    const attendance = clamp(jitter(18), 0, 100);
    const internal = clamp(jitter(21), 0, 100);
    const assignment = clamp(jitter(24), 0, 100);
    const practical = clamp(jitter(22), 0, 100);
    const previous = clamp(jitter(25), 0, 100);
    const study = Math.round((group === 0 ? 1 : group === 1 ? 8 : 16) + random() * (group === 0 ? 10 : group === 1 ? 15 : 22));
    const participation = clamp(jitter(28), 0, 100);
    const marks = clamp(Math.round(internal * 0.42 + assignment * 0.24 + practical * 0.18 + previous * 0.16 + (random() - 0.5) * 12), 0, 100);
    const latent = attendance * 0.15 + marks * 0.16 + internal * 0.17 + assignment * 0.12 + practical * 0.11 + previous * 0.15 + Math.min(100, study * 2.5) * 0.07 + participation * 0.07 + (random() - 0.5) * 10;
    const label = latent >= 80 ? 'high-performing' : latent >= 58 ? 'average-performing' : 'at-risk';
    return { features: [attendance, marks, internal, assignment, practical, previous, study, participation], label };
  });
}

const HEADER_ALIASES: Record<string, (typeof FEATURE_KEYS)[number] | 'outcome'> = {
  attendance: 'attendance', attendancepercentage: 'attendance', attendancepercent: 'attendance', attendancerate: 'attendance',
  marks: 'marks', mark: 'marks', currentmarks: 'marks', averagemarks: 'marks', totalmarks: 'marks', overallmarks: 'marks', internalmarks: 'internalMarks', internalexam: 'internalMarks', internalexamscore: 'internalMarks', internalexamscores: 'internalMarks', internalexaminationmarks: 'internalMarks',
  assignment: 'assignmentScore', assignments: 'assignmentScore', assignmentscore: 'assignmentScore', assignmentmarks: 'assignmentScore',
  practical: 'practicalScore', practicalscore: 'practicalScore', practicalmarks: 'practicalScore',
  previoussemester: 'previousSemester', previoussemestermarks: 'previousSemester', previoussemesterscore: 'previousSemester', prevsemester: 'previousSemester', prevsemestermarks: 'previousSemester',
  studyhours: 'studyHours', weeklystudyhours: 'studyHours', studyhour: 'studyHours',
  participation: 'participation', participationscore: 'participation', academicparticipation: 'participation', activityparticipation: 'participation',
  outcome: 'outcome', performance: 'outcome', performancecategory: 'outcome', finalresult: 'outcome', result: 'outcome', label: 'outcome', gradecategory: 'outcome',
};

function parseCsv(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = []; let cell = ''; let quoted = false;
  const input = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    if (char === '"') {
      if (quoted && input[i + 1] === '"') { cell += '"'; i++; }
      else quoted = !quoted;
    } else if (char === ',' && !quoted) { row.push(cell.trim()); cell = ''; }
    else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && input[i + 1] === '\n') i++;
      row.push(cell.trim()); if (row.some((item) => item.length)) rows.push(row);
      row = []; cell = '';
    } else cell += char;
  }
  if (quoted) throw new Error('The CSV contains an unclosed quoted field.');
  if (cell.length || row.length) { row.push(cell.trim()); if (row.some((item) => item.length)) rows.push(row); }
  return rows;
}

function normalizeOutcome(value: string): Outcome | null {
  const word = value.trim().toLowerCase().replace(/[_\s]+/g, '-');
  if (/^(high|high-performing|high-performance|excellent|excellent-performing|top|distinction|a\+?)$/.test(word)) return 'high-performing';
  if (/^(average|average-performing|average-performance|medium|moderate|satisfactory|pass|b|c)$/.test(word)) return 'average-performing';
  if (/^(at-risk|risk|low|low-performing|low-performance|poor|fail|f|d|e)$/.test(word)) return 'at-risk';
  return null;
}
function numberFromCell(value: string, index: number): number | null {
  const raw = value.trim().replace(/%$/, '').replace(/,/g, '');
  if (!raw) return null;
  const parsed = Number(raw);
  if (!Number.isFinite(parsed)) return null;
  const max = index === 6 ? 40 : 100;
  return parsed < 0 || parsed > max ? Number.NaN : parsed;
}
function median(values: number[], fallback: number) {
  if (!values.length) return fallback;
  const sorted = [...values].sort((a, b) => a - b); const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function parseHistoricalCsv(text: string): { rows: TrainingRow[]; stats: ImportStats } {
  const parsed = parseCsv(text);
  if (parsed.length < 2) throw new Error('Add a header row and at least 15 labeled history rows.');
  const headers = parsed[0].map((header) => HEADER_ALIASES[header.toLowerCase().replace(/[^a-z0-9]/g, '')]);
  const outcomeIndex = headers.indexOf('outcome');
  if (outcomeIndex < 0) throw new Error('The CSV needs a labeled outcome column: outcome, performance, result, or label.');
  const presentFeatureCount = FEATURE_KEYS.filter((key) => headers.includes(key)).length;
  if (presentFeatureCount < 3) throw new Error('Include at least three recognized academic input columns, such as attendance, marks, and assignment score.');
  const raw: { values: (number | null)[]; label: Outcome }[] = [];
  let rejectedRows = 0; let duplicateRows = 0; let imputedCells = 0; const notes: string[] = [];
  const seen = new Set<string>();
  for (const fields of parsed.slice(1)) {
    if (!fields.some((field) => field.trim())) continue;
    if (fields.length !== headers.length) { rejectedRows++; continue; }
    const label = normalizeOutcome(fields[outcomeIndex] ?? '');
    const values = FEATURE_KEYS.map((feature, featureIndex) => {
      const columnIndex = headers.indexOf(feature);
      return columnIndex < 0 ? null : numberFromCell(fields[columnIndex] ?? '', featureIndex);
    });
    if (!label || values.some((value) => typeof value === 'number' && Number.isNaN(value))) { rejectedRows++; continue; }
    const key = `${values.join('|')}|${label}`;
    if (seen.has(key)) { duplicateRows++; continue; }
    seen.add(key); raw.push({ values, label });
  }
  if (raw.length < 15) throw new Error(`Only ${raw.length} valid, unique labeled rows were found; at least 15 are needed to evaluate models.`);
  raw.forEach((row) => row.values.forEach((value) => { if (value === null) imputedCells++; }));
  const rows = raw.map((row) => ({ features: row.values, label: row.label }));
  if (imputedCells) notes.push(`${imputedCells} missing numeric cells were imputed using column medians.`);
  if (duplicateRows) notes.push(`${duplicateRows} duplicate labeled rows were removed.`);
  if (rejectedRows) notes.push(`${rejectedRows} rows with malformed column counts, invalid values, or labels were rejected.`);
  const absent = FEATURE_KEYS.filter((feature) => !headers.includes(feature)).map((feature) => FEATURE_LABELS[feature]);
  if (absent.length) notes.push(`Columns not supplied (${absent.join(', ')}) use demo-range defaults; provide these fields for better evaluation.`);
  return { rows, stats: { rowsRead: parsed.length - 1, accepted: rows.length, imputedCells, rejectedRows, duplicateRows, notes } };
}

export function loadTrainingSet(): { rows: TrainingRow[]; source: DatasetSource } {
  try {
    const stored = localStorage.getItem(TRAINING_STORAGE_KEY);
    if (!stored) return { rows: createSyntheticHistory(), source: 'synthetic' };
    const value: unknown = JSON.parse(stored);
    if (value && typeof value === 'object' && Array.isArray((value as { rows?: unknown }).rows)) {
      const record = value as { rows: unknown[]; source?: unknown };
      const rows = record.rows.filter((item): item is TrainingRow => Boolean(item && typeof item === 'object' && Array.isArray((item as TrainingRow).features) && (item as TrainingRow).features.length === FEATURE_KEYS.length && (item as TrainingRow).features.every((number) => number === null || (typeof number === 'number' && Number.isFinite(number))) && OUTCOMES.includes((item as TrainingRow).label)));
      if (rows.length >= 15) return { rows, source: record.source === 'uploaded' ? 'uploaded' : 'synthetic' };
    }
  } catch (error) { console.warn('Could not read the local training set.', error); }
  return { rows: createSyntheticHistory(), source: 'synthetic' };
}

function gini(rows: CleanTrainingRow[]) {
  if (!rows.length) return 0;
  const counts = new Map<Outcome, number>(); rows.forEach((row) => counts.set(row.label, (counts.get(row.label) ?? 0) + 1));
  return 1 - [...counts.values()].reduce((sum, count) => sum + (count / rows.length) ** 2, 0);
}
function majority(rows: CleanTrainingRow[]): Outcome {
  const counts: Record<Outcome, number> = { 'high-performing': 0, 'average-performing': 0, 'at-risk': 0 };
  rows.forEach((row) => counts[row.label]++);
  return OUTCOMES.reduce((best, label) => counts[label] > counts[best] ? label : best, OUTCOMES[0]);
}
function variedThresholds(rows: CleanTrainingRow[], feature: number) {
  const values = [...new Set(rows.map((row) => row.features[feature]))].sort((a, b) => a - b);
  const cuts = values.length <= 18 ? values.slice(1).map((value, index) => (values[index] + value) / 2) : Array.from({ length: 16 }, (_, i) => values[Math.floor((i + 1) * (values.length - 1) / 17)]).filter((value, i, list) => i === 0 || value !== list[i - 1]);
  return cuts;
}
type TreeNode = { label: Outcome; score: number; feature?: number; threshold?: number; left?: TreeNode; right?: TreeNode };
function buildTree(rows: CleanTrainingRow[], random: () => number, depth = 0, importance = Array(FEATURE_KEYS.length).fill(0), featureSubset?: number): TreeNode {
  const label = majority(rows); const score = meanClassScore(rows);
  if (depth >= 5 || rows.length < 8 || gini(rows) < 0.015) return { label, score };
  const parent = gini(rows); let bestGain = 0; let bestFeature = -1; let bestThreshold = 0; let bestLeft: CleanTrainingRow[] = []; let bestRight: CleanTrainingRow[] = [];
  let features = FEATURE_KEYS.map((_, index) => index);
  if (featureSubset && featureSubset < features.length) features = features.sort(() => random() - 0.5).slice(0, featureSubset);
  for (const feature of features) for (const threshold of variedThresholds(rows, feature)) {
    const left = rows.filter((row) => row.features[feature] <= threshold); const right = rows.filter((row) => row.features[feature] > threshold);
    if (left.length < 3 || right.length < 3) continue;
    const gain = parent - (left.length / rows.length * gini(left) + right.length / rows.length * gini(right));
    if (gain > bestGain) { bestGain = gain; bestFeature = feature; bestThreshold = threshold; bestLeft = left; bestRight = right; }
  }
  if (bestFeature < 0 || bestGain < 0.003) return { label, score };
  importance[bestFeature] += bestGain * rows.length;
  return { label, score, feature: bestFeature, threshold: bestThreshold, left: buildTree(bestLeft, random, depth + 1, importance, featureSubset), right: buildTree(bestRight, random, depth + 1, importance, featureSubset) };
}
function treePredict(node: TreeNode, features: number[]): { label: Outcome; score: number } {
  if (node.feature === undefined || node.threshold === undefined || !node.left || !node.right) return { label: node.label, score: node.score };
  return treePredict(features[node.feature] <= node.threshold ? node.left : node.right, features);
}
function normalImportance(values: number[]) { const total = values.reduce((sum, value) => sum + Math.max(0, value), 0); return total ? values.map((value) => Math.max(0, value) / total) : values.map(() => 1 / values.length); }
function fitTree(rows: CleanTrainingRow[], seed: number, forest = false): FittedModel {
  const importance = Array(FEATURE_KEYS.length).fill(0); const random = seededRandom(seed);
  const treeCount = forest ? 17 : 1; const trees: TreeNode[] = [];
  for (let i = 0; i < treeCount; i++) {
    const sample = forest ? Array.from({ length: rows.length }, () => rows[Math.floor(random() * rows.length)]) : rows;
    trees.push(buildTree(sample, random, 0, importance, forest ? 3 : undefined));
  }
  return {
    id: forest ? 'random-forest' : 'decision-tree', name: forest ? 'Random Forest' : 'Decision Tree', importance: normalImportance(importance),
    predict(features) {
      const predictions = trees.map((tree) => treePredict(tree, features));
      const votes: Record<Outcome, number> = { 'high-performing': 0, 'average-performing': 0, 'at-risk': 0 };
      predictions.forEach((prediction) => votes[prediction.label]++);
      const label = OUTCOMES.reduce((best, outcome) => votes[outcome] > votes[best] ? outcome : best, OUTCOMES[0]);
      return { label, score: Math.round(predictions.reduce((sum, prediction) => sum + prediction.score, 0) / predictions.length) };
    },
  };
}
function fitLinearRegression(rows: CleanTrainingRow[]): FittedModel {
  const weights = Array(FEATURE_KEYS.length).fill(0); let bias = meanClassScore(rows);
  const data = rows.map((row) => ({ x: scaled(row.features), y: classScore[row.label] }));
  for (let epoch = 0; epoch < 700; epoch++) {
    const gradients = Array(FEATURE_KEYS.length).fill(0); let biasGradient = 0;
    for (const row of data) { const predicted = bias + weights.reduce((sum, weight, index) => sum + weight * row.x[index], 0); const error = predicted - row.y; biasGradient += error; weights.forEach((_, index) => gradients[index] += error * row.x[index]); }
    const rate = 0.12 / data.length;
    bias -= rate * biasGradient;
    weights.forEach((_, index) => { weights[index] -= rate * (gradients[index] + 0.03 * weights[index]); });
  }
  return { id: 'linear-regression', name: 'Linear Regression', importance: normalImportance(weights.map(Math.abs)), predict(features) { const score = clamp(bias + weights.reduce((sum, weight, index) => sum + weight * scaled(features)[index], 0), 0, 100); return { score: Math.round(score), label: scoreOutcome(score) }; } };
}
function softmax(values: number[]) { const max = Math.max(...values); const exp = values.map((value) => Math.exp(value - max)); const total = exp.reduce((sum, value) => sum + value, 0); return exp.map((value) => value / total); }
function fitLogistic(rows: CleanTrainingRow[], svm = false): FittedModel {
  const classIndex = (label: Outcome) => OUTCOMES.indexOf(label);
  const dimension = FEATURE_KEYS.length + 1;
  const data = rows.map((row) => ({ x: [...scaled(row.features), 1], target: classIndex(row.label) }));
  const importance = Array(FEATURE_KEYS.length).fill(0);

  if (svm) {
    const random = seededRandom(911);
    const pairs: { left: number; right: number; vector: number[] }[] = [];
    for (let left = 0; left < OUTCOMES.length; left++) for (let right = left + 1; right < OUTCOMES.length; right++) {
      const pairRows = data.filter((row) => row.target === left || row.target === right);
      const vector = Array(dimension).fill(0);
      for (let epoch = 0; epoch < 160; epoch++) {
        const ordered = [...pairRows.keys()];
        for (let index = ordered.length - 1; index > 0; index--) { const swap = Math.floor(random() * (index + 1)); [ordered[index], ordered[swap]] = [ordered[swap], ordered[index]]; }
        const rate = 0.04 / (1 + epoch * 0.005);
        for (const orderIndex of ordered) {
          const row = pairRows[orderIndex]; const sign = row.target === left ? 1 : -1;
          const margin = sign * vector.reduce((sum, value, index) => sum + value * row.x[index], 0);
          for (let index = 0; index < dimension - 1; index++) { vector[index] *= 1 - rate * 0.015; if (margin < 1) vector[index] += rate * sign * row.x[index]; }
          if (margin < 1) vector[dimension - 1] += rate * sign;
        }
      }
      vector.slice(0, FEATURE_KEYS.length).forEach((value, feature) => importance[feature] += Math.abs(value));
      pairs.push({ left, right, vector });
    }
    return {
      id: 'svm', name: 'Support Vector Machine', importance: normalImportance(importance),
      predict(features) {
        const vector = [...scaled(features), 1]; const votes = OUTCOMES.map(() => 0); const margins = OUTCOMES.map(() => 0);
        pairs.forEach((pair) => { const margin = pair.vector.reduce((sum, value, index) => sum + value * vector[index], 0); const winner = margin >= 0 ? pair.left : pair.right; votes[winner]++; margins[pair.left] += margin; margins[pair.right] -= margin; });
        const decisionScores = votes.map((vote, index) => vote * 3 + margins[index]);
        const best = decisionScores.indexOf(Math.max(...decisionScores)); const probabilities = softmax(decisionScores);
        const score = probabilities.reduce((sum, probability, index) => sum + probability * classScore[OUTCOMES[index]], 0);
        return { label: OUTCOMES[best], score: Math.round(score) };
      },
    };
  }

  const weights = OUTCOMES.map(() => Array(dimension).fill(0));
  for (let epoch = 0; epoch < 620; epoch++) {
    const gradients = OUTCOMES.map(() => Array(dimension).fill(0));
    data.forEach((row) => {
      const probs = softmax(weights.map((weight) => weight.reduce((sum, value, index) => sum + value * row.x[index], 0)));
      OUTCOMES.forEach((_, cls) => { const error = probs[cls] - (row.target === cls ? 1 : 0); row.x.forEach((feature, index) => gradients[cls][index] += error * feature); });
    });
    weights.forEach((weight, cls) => weight.forEach((_, index) => { weight[index] -= 0.38 * ((gradients[cls][index] / rows.length) + (index < FEATURE_KEYS.length ? 0.006 * weight[index] : 0)); }));
  }
  for (let feature = 0; feature < FEATURE_KEYS.length; feature++) importance[feature] = OUTCOMES.reduce((sum, _, cls) => sum + Math.abs(weights[cls][feature]), 0);
  return {
    id: 'logistic-regression', name: 'Logistic Regression', importance: normalImportance(importance),
    predict(features) {
      const vector = [...scaled(features), 1]; const raw = weights.map((weight) => weight.reduce((sum, value, index) => sum + value * vector[index], 0));
      const probs = softmax(raw); const predictedIndex = raw.indexOf(Math.max(...raw));
      const score = probs.reduce((sum, probability, index) => sum + probability * classScore[OUTCOMES[index]], 0);
      return { label: OUTCOMES[predictedIndex], score: Math.round(score) };
    },
  };
}
function fitModel(id: AlgorithmId, rows: CleanTrainingRow[], seed: number): FittedModel {
  if (id === 'linear-regression') return fitLinearRegression(rows);
  if (id === 'decision-tree') return fitTree(rows, seed, false);
  if (id === 'random-forest') return fitTree(rows, seed, true);
  if (id === 'logistic-regression') return fitLogistic(rows, false);
  return fitLogistic(rows, true);
}
function imputationMedians(rows: TrainingRow[]) {
  return FEATURE_KEYS.map((_, index) => median(rows.map((row) => row.features[index]).filter((value): value is number => value !== null && Number.isFinite(value)), DEFAULT_FEATURES[index]));
}
function imputeRows(rows: TrainingRow[], medians: number[]): CleanTrainingRow[] {
  return rows.map((row) => ({ label: row.label, features: row.features.map((value, index) => value === null ? medians[index] : value) }));
}

function splitRows(rows: TrainingRow[], seed: number) {
  const random = seededRandom(seed); const training: TrainingRow[] = []; const testing: TrainingRow[] = [];
  for (const outcome of OUTCOMES) {
    const bucket = rows.filter((row) => row.label === outcome).map((row) => ({ row, order: random() })).sort((a, b) => a.order - b.order);
    const testCount = bucket.length > 1 ? Math.max(1, Math.round(bucket.length * 0.2)) : 0;
    bucket.forEach((item, index) => (index < testCount ? testing : training).push(item.row));
  }
  return { training, testing };
}
function metrics(id: AlgorithmId, model: FittedModel, rows: CleanTrainingRow[]): ModelMetrics {
  const matrix = OUTCOMES.map(() => OUTCOMES.map(() => 0)); let correct = 0; let absoluteError = 0; let squaredError = 0;
  rows.forEach((row) => { const result = model.predict(row.features); const actual = OUTCOMES.indexOf(row.label); const predicted = OUTCOMES.indexOf(result.label); matrix[actual][predicted]++; if (actual === predicted) correct++; const error = result.score - classScore[row.label]; absoluteError += Math.abs(error); squaredError += error * error; });
  const classScores = OUTCOMES.map((_, index) => { const tp = matrix[index][index]; const fp = matrix.reduce((sum, row, actual) => sum + (actual === index ? 0 : row[index]), 0); const fn = matrix[index].reduce((sum, count, predicted) => sum + (predicted === index ? 0 : count), 0); const precision = tp + fp ? tp / (tp + fp) : 0; const recall = tp + fn ? tp / (tp + fn) : 0; return { precision, recall, f1: precision + recall ? 2 * precision * recall / (precision + recall) : 0 }; });
  const length = Math.max(1, rows.length);
  return { id, name: model.name, accuracy: correct / length, precision: classScores.reduce((sum, item) => sum + item.precision, 0) / 3, recall: classScores.reduce((sum, item) => sum + item.recall, 0) / 3, f1: classScores.reduce((sum, item) => sum + item.f1, 0) / 3, mae: absoluteError / length, rmse: Math.sqrt(squaredError / length), confusion: matrix, importance: model.importance };
}

export function evaluateModels(rows: TrainingRow[], source: DatasetSource): ModelRun {
  const labels = new Set(rows.map((row) => row.label));
  const usedSyntheticFallback = rows.length < 15 || labels.size < 2;
  const evaluationRows = usedSyntheticFallback ? createSyntheticHistory() : rows;
  const evaluationSource: DatasetSource = usedSyntheticFallback ? 'synthetic' : source;
  const split = splitRows(evaluationRows, 2861);
  const medians = imputationMedians(split.training);
  const training = imputeRows(split.training, medians);
  const testing = imputeRows(split.testing, medians);
  const results = ALGORITHMS.map((algorithm, index) => metrics(algorithm.id, fitModel(algorithm.id, training, 2861 + index * 73), testing));
  const best = [...results].sort((a, b) => b.f1 - a.f1 || a.mae - b.mae)[0];
  const selected = fitModel(best.id, imputeRows(evaluationRows, imputationMedians(evaluationRows)), 9217);
  return {
    rows: evaluationRows, source: evaluationSource, inputSource: source, usedSyntheticFallback,
    evaluated: split.testing.length, trainingCount: split.training.length, results, selected, selectedMetrics: best,
    error: usedSyntheticFallback ? 'Imported history needs at least 15 rows across at least two labeled outcome categories. Evaluation and live predictions use the synthetic starter set instead.' : undefined,
  };
}

export function predictWithModel(student: Student, model: FittedModel) {
  const features = vectorForStudent(student); const prediction = model.predict(features);
  const topFactors = model.importance.map((value, index) => ({ value, label: FEATURE_LABELS[FEATURE_KEYS[index]] })).sort((a, b) => b.value - a.value).slice(0, 2).map((item) => item.label.toLowerCase());
  const note = prediction.label === 'at-risk'
    ? `The model flags an early-support signal. Review attendance (${student.attendance}%) and the underlying assessment factors with the learner.`
    : `Model signals are strongest for ${topFactors.join(' and ')}. Use the estimate as a prompt for a supportive check-in, not a verdict.`;
  return { score: prediction.score, label: OUTCOME_LABEL[prediction.label], note, modelName: model.name };
}
