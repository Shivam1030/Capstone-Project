import { useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  Activity, AlertCircle, ArrowDown, ArrowDownUp, ArrowRight, ArrowUpRight, BarChart3, Bell, BookOpen, BrainCircuit,
  CalendarDays, Check, ChevronDown, ChevronLeft, ChevronRight, Download, FileDown,
  FileSpreadsheet, Filter, LayoutDashboard, Mail, Menu, Moon, MoreHorizontal,
  Plus, Printer, Search, ShieldCheck, Sparkles, Sun, Trash2, TrendingUp, Users, X, Pencil,
  Eye, Phone, CheckCircle2, Info, RotateCcw,
} from 'lucide-react';
import {
  Area, AreaChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import {
  average, initials, loadStudents, predictionTone, starterStudents, STORAGE_KEY,
  type Student, type Prediction,
} from './data/students';
import { createSyntheticHistory, evaluateModels, FEATURE_KEYS, FEATURE_LABELS, loadTrainingSet, parseHistoricalCsv, predictWithModel, TRAINING_STORAGE_KEY, type DatasetSource, type ImportStats, type TrainingRow, type ModelRun } from './data/ml';
import ModelLab from './components/ModelLab';
import AIChat, { type ChatSummary } from './components/AIChat';

type View = 'Overview' | 'Students' | 'Analytics' | 'Model Lab' | 'Reports';
type FormValues = Omit<Student, 'id' | 'updatedAt'>;
const navItems: { name: View; icon: typeof LayoutDashboard }[] = [
  { name: 'Overview', icon: LayoutDashboard }, { name: 'Students', icon: Users },
  { name: 'Analytics', icon: BarChart3 }, { name: 'Model Lab', icon: BrainCircuit }, { name: 'Reports', icon: FileSpreadsheet },
];
const tones = ['#15a58e', '#94b6ad', '#d8a35a', '#df7869'];
const blankForm: FormValues = { name: '', email: '', phone: '', attendance: 90, marks: 80, internalMarks: 80, assignmentScore: 80, practicalScore: 80, previousSemester: 75, studyHours: 12, participation: 75, course: 'Computer Science', year: 'Year 1' };
const modelInputFields = [{key:'attendance',label:'Attendance',max:100,unit:'%',step:1},{key:'marks',label:'Current marks',max:100,unit:'%',step:1},{key:'internalMarks',label:'Internal exam',max:100,unit:'%',step:1},{key:'assignmentScore',label:'Assignments',max:100,unit:'%',step:1},{key:'practicalScore',label:'Practical work',max:100,unit:'%',step:1},{key:'previousSemester',label:'Previous semester',max:100,unit:'%',step:1},{key:'studyHours',label:'Study hours / week',max:40,unit:'h',step:1},{key:'participation',label:'Academic participation',max:100,unit:'%',step:1}] as const;


function escapeCsv(value: string | number) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

function evaluationSourceLabel(run: ModelRun) {
  if (run.usedSyntheticFallback) return 'Synthetic starter fallback; uploaded labels lack two outcome classes';
  return run.source === 'synthetic' ? 'Synthetic starter examples; not institutional history' : 'Locally imported labeled history';
}
function evaluationDisclaimer(run: ModelRun) {
  if (run.usedSyntheticFallback) return 'Imported history did not contain at least two outcome classes or enough valid rows; model comparisons and estimates use synthetic starter examples instead.';
  return run.source === 'synthetic' ? 'Synthetic starter metrics are illustrative only and do not validate performance for any institution.' : 'Metrics describe only this browser-held historical dataset split; they do not guarantee future outcomes.';
}

function downloadCsv(students: Student[], run: ModelRun, name = 'student-performance-report.csv') {
  const headers = ['Student ID', 'Name', 'Email', 'Phone', 'Course', 'Year', 'Attendance %', 'Current marks %', 'Internal marks %', 'Assignment %', 'Practical %', 'Previous semester %', 'Study hours / week', 'Academic participation %', 'Predicted score', 'Predicted category (not ground truth)', 'Model', 'Evaluation source', 'Evaluation rows', 'Training rows', 'Held-out rows', 'Held-out macro F1 %', 'Advisory note'];
  const rows = students.map((student) => {
    const result = predictWithModel(student, run.selected);
    return [student.id, student.name, student.email, student.phone, student.course, student.year, student.attendance, student.marks, student.internalMarks, student.assignmentScore, student.practicalScore, student.previousSemester, student.studyHours, student.participation, result.score, result.label, run.selected.name, evaluationSourceLabel(run), run.rows.length, run.trainingCount, run.evaluated, Math.round(run.selectedMetrics.f1 * 100), evaluationDisclaimer(run)];
  });
  const content = [headers, ...rows].map((row) => row.map(escapeCsv).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([`\uFEFF${content}`], { type: 'text/csv;charset=utf-8;' }));
  const link = document.createElement('a'); link.href = url; link.download = name; link.click(); URL.revokeObjectURL(url);
}

async function downloadPdf(students: Student[], run: ModelRun, title = 'Student performance report') {
  const { default: jsPDF } = await import('jspdf');
  const doc = new jsPDF({ orientation: 'landscape' });
  const margin = 16;
  const pageWidth = doc.internal.pageSize.getWidth();
  const columns = [14, 42, 99, 151, 179, 205, 257];
  const drawPageHeader = () => {
    doc.setFillColor(20, 37, 40); doc.rect(0, 0, pageWidth, 36, 'F');
    doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(12);
    doc.text('AI-Based Student Performance Prediction System', margin, 15);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
    doc.text(title, margin, 25);
    doc.text(`Prepared ${new Date().toLocaleDateString()}  ·  ${students.length} students  ·  Indicative estimates`, pageWidth - margin, 25, { align: 'right' });
    doc.setTextColor(33, 49, 50); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
    ['STUDENT', 'EMAIL / PHONE', 'COURSE', 'ATTEND.', 'MARKS', 'ACADEMIC INPUTS', 'MODEL OUTCOME'].forEach((label, index) => doc.text(label, columns[index], 47));
    doc.setDrawColor(220, 226, 221); doc.line(margin, 51, pageWidth - margin, 51);
    return 60;
  };
  let y = drawPageHeader();
  students.forEach((student) => {
    if (y > 171) { doc.addPage(); y = drawPageHeader(); }
    const result = predictWithModel(student, run.selected);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(46, 62, 61);
    doc.text([student.name, student.id], columns[0], y, { maxWidth: 26 });
    doc.text([student.email, student.phone], columns[1], y, { maxWidth: 53 });
    doc.text(student.course, columns[2], y, { maxWidth: 48 });
    doc.text(`${student.attendance}%`, columns[3], y);
    doc.text(`${student.marks}%`, columns[4], y);
    doc.text([`Internal ${student.internalMarks}% · Assignment ${student.assignmentScore}%`, `Practical ${student.practicalScore}% · Prior ${student.previousSemester}%`, `Study ${student.studyHours}h/wk · Participation ${student.participation}%`], columns[5], y - 1, { maxWidth: 48 });
    doc.setFont('helvetica', 'bold'); doc.text([`${result.score}%`, result.label], columns[6], y, { maxWidth: 26 });
    doc.setDrawColor(237, 239, 236); doc.line(margin, y + 12, pageWidth - margin, y + 12); y += 17;
  });
  const pageCount = doc.getNumberOfPages();
  for (let page = 1; page <= pageCount; page++) {
    doc.setPage(page); doc.setDrawColor(220, 226, 221); doc.line(margin, 191, pageWidth - margin, 191);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(120, 135, 128);
    const sourceLine = `${run.selected.name} · held-out Macro F1 ${Math.round(run.selectedMetrics.f1 * 100)}% · ${evaluationSourceLabel(run)} · advisory only.`;
    doc.text(doc.splitTextToSize(sourceLine, pageWidth - margin * 2), margin, 196);
    doc.text(doc.splitTextToSize(evaluationDisclaimer(run), pageWidth - margin * 2), margin, 200);
    doc.text(`Page ${page} of ${pageCount}`, pageWidth - margin, 204, { align: 'right' });
  }
  doc.save('student-performance-report.pdf');
}

function readThemePreference() {
  try { return localStorage.getItem('student-insight-theme') || 'light'; }
  catch { return 'light'; }
}

function App() {
  const [students, setStudents] = useState<Student[]>(loadStudents);
  const [history, setHistory] = useState<{rows:TrainingRow[];source:DatasetSource}>(loadTrainingSet);
  const [importStats, setImportStats] = useState<ImportStats|null>(null);
  const [trainingStorageWarning, setTrainingStorageWarning] = useState('');
  const [view, setView] = useState<View>('Overview');
  const [theme, setTheme] = useState(readThemePreference);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All students');
  const [courseFilter, setCourseFilter] = useState('All courses');
  const [sortField, setSortField] = useState<'name' | 'attendance' | 'marks'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [detail, setDetail] = useState<Student | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);
  const [form, setForm] = useState<FormValues>(blankForm);
  const [formError, setFormError] = useState('');
  const [toast, setToast] = useState('');
  const [exporting, setExporting] = useState(false);
  const [storageWarning, setStorageWarning] = useState('');
  const [printTarget, setPrintTarget] = useState<Student | null>(null);
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(students)); setStorageWarning(''); }
    catch (error) { console.warn('Could not save student records.', error); setStorageWarning('Changes could not be saved in this browser. Export a backup.'); }
  }, [students]);
  useEffect(() => {
    try { localStorage.setItem(TRAINING_STORAGE_KEY, JSON.stringify(history)); setTrainingStorageWarning(''); }
    catch (error) { console.warn('Could not save the local historical training set.', error); setTrainingStorageWarning('This training set could not be saved in this browser. Export your source CSV before leaving.'); }
  }, [history]);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('student-insight-theme', theme); } catch (error) { console.warn('Could not save the theme preference.', error); }
  }, [theme]);
  useEffect(() => { const clearPrintTarget = () => setPrintTarget(null); window.addEventListener('afterprint', clearPrintTarget); return () => window.removeEventListener('afterprint', clearPrintTarget); }, []);
  useEffect(() => setPage(1), [query, statusFilter, courseFilter]);
  useEffect(() => { if (!toast) return; const timer = window.setTimeout(() => setToast(''), 3300); return () => window.clearTimeout(timer); }, [toast]);

  const modelRun = useMemo(() => evaluateModels(history.rows, history.source), [history]);
  const enriched = useMemo(() => students.map((student) => ({ ...student, prediction: predictWithModel(student, modelRun.selected) })), [students, modelRun]);
  const averageMark = Math.round(average(students.map((student) => student.marks)));
  const averageAttendance = Math.round(average(students.map((student) => student.attendance)));
  const classScore = Math.round(average(enriched.map((student) => student.prediction.score)));
  const atRisk = enriched.filter((student) => student.prediction.label === 'At-risk').length;
  const trendData = [{week:'Previous semester',score:Math.round(average(students.map((student)=>student.previousSemester)))},{week:'Current term',score:averageMark}];
  const counts = { high: enriched.filter((student)=>student.prediction.label==='High-performing').length, average: enriched.filter((student)=>student.prediction.label==='Average-performing').length, risk: atRisk };
  const factorLabels = [...FEATURE_KEYS].map((key,index)=>({value:modelRun.selected.importance[index]??0,label:FEATURE_LABELS[key]})).sort((a,b)=>b.value-a.value).slice(0,3).map((item)=>item.label);
  const chatSummary: ChatSummary = { studentCount:students.length, averageAttendance, averageMarks:averageMark, averageModelScore:classScore, atRiskCount:counts.risk, highPerformingCount:counts.high, averagePerformingCount:counts.average, modelName:modelRun.selected.name, validationMacroF1:Math.round(modelRun.selectedMetrics.f1*100), trainingRowCount:modelRun.rows.length, datasetSource:modelRun.source, topFactors:factorLabels };
  const courseNames = Array.from(new Set(students.map((student) => student.course)));
  const filtered = useMemo(() => enriched.filter((student) => {
    const matchText = `${student.name} ${student.email} ${student.phone} ${student.id} ${student.course}`.toLowerCase().includes(query.toLowerCase());
    const matchStatus = statusFilter === 'All students' || student.prediction.label === statusFilter;
    const matchCourse = courseFilter === 'All courses' || student.course === courseFilter;
    return matchText && matchStatus && matchCourse;
  }).sort((a, b) => {
    const comparison = sortField === 'name' ? a.name.localeCompare(b.name) : a[sortField] - b[sortField];
    return sortDirection === 'asc' ? comparison : -comparison;
  }), [enriched, query, statusFilter, courseFilter, sortField, sortDirection]);
  const pageSize = 10;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageStudents = filtered.slice((page - 1) * pageSize, page * pageSize);
  useEffect(() => setPage((current) => Math.min(current, pageCount)), [pageCount]);
  const distribution = [
    { name: 'High-performing', count: counts.high },
    { name: 'Average-performing', count: counts.average },
    { name: 'At-risk', count: counts.risk },
  ];

  function openCreate() { setEditing(null); setForm(blankForm); setFormError(''); setFormOpen(true); }
  function openEdit(student: Student) { setEditing(student); setForm({ name: student.name, email: student.email, phone: student.phone, attendance: student.attendance, marks: student.marks, internalMarks: student.internalMarks, assignmentScore: student.assignmentScore, practicalScore: student.practicalScore, previousSemester: student.previousSemester, studyHours: student.studyHours, participation: student.participation, course: student.course, year: student.year }); setFormError(''); setFormOpen(true); setDetail(null); }
  function saveStudent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (form.name.trim().length < 2) return setFormError('Please enter the student’s full name.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) return setFormError('Enter a valid email address.');
    if (form.phone.replace(/\D/g, '').length < 7) return setFormError('Enter a phone number with at least 7 digits.');
    if (students.some((student) => student.email.toLowerCase() === form.email.toLowerCase() && student.id !== editing?.id)) return setFormError('That email already belongs to a student.');
    if ([form.attendance, form.marks, form.internalMarks, form.assignmentScore, form.practicalScore, form.previousSemester, form.participation].some((value) => !Number.isFinite(value) || value < 0 || value > 100) || !Number.isFinite(form.studyHours) || form.studyHours < 0 || form.studyHours > 40) return setFormError('Check the academic inputs. Scores must be 0–100 and study hours 0–40.');
    const record: Student = { ...form, name: form.name.trim(), email: form.email.trim(), phone: form.phone.trim(), id: editing?.id || `ST-${Date.now().toString().slice(-6)}`, updatedAt: new Date().toISOString() };
    setStudents((current) => editing ? current.map((student) => student.id === editing.id ? record : student) : [record, ...current]);
    setFormOpen(false); setToast(editing ? 'Student record updated.' : 'Student added to your class.');
  }
  function confirmDelete() { if (!deleteTarget) return; setStudents((current) => current.filter((student) => student.id !== deleteTarget.id)); setToast(`${deleteTarget.name}’s record was removed.`); setDeleteTarget(null); setDetail(null); }
  function handleSort(field: 'name' | 'attendance' | 'marks') { if (sortField === field) setSortDirection((current) => current === 'asc' ? 'desc' : 'asc'); else { setSortField(field); setSortDirection(field === 'name' ? 'asc' : 'desc'); } }
  async function handlePdfExport(records: Student[] = students, title?: string) {
    if (exporting) return;
    setExporting(true);
    try { await downloadPdf(records, modelRun, title); setToast('PDF report downloaded.'); }
    catch (error) { console.error('Could not generate the PDF report.', error); setToast('PDF export failed. Please try again or use Print.'); }
    finally { setExporting(false); }
  }
  function printStudentReport(student: Student) { setPrintTarget(student); window.setTimeout(() => window.print(), 100); }
  function printAggregate() { setPrintTarget(null); window.setTimeout(() => window.print(), 100); }
  function handleReset() { if (!window.confirm('Restore the original fictional sample class? Your current browser-saved changes will be replaced.')) return; setStudents(starterStudents); setToast('Sample class restored.'); }
  async function handleHistoryImport(event: FormEvent<HTMLInputElement>) { const input=event.currentTarget; const file=input.files?.[0]; if(!file)return; if(file.size>2_000_000){setImportStats(null);setTrainingStorageWarning('Please choose a CSV under 2 MB.');input.value='';return;} try { const parsed=parseHistoricalCsv(await file.text()); if(parsed.rows.length>2500) throw new Error('This browser prototype supports up to 2,500 labeled rows per import.'); setHistory({rows:parsed.rows,source:'uploaded'});setImportStats(parsed.stats);setTrainingStorageWarning('');setToast('Historical dataset imported and evaluated locally.'); } catch(error) { setTrainingStorageWarning(error instanceof Error?error.message:'Could not read that CSV file.'); } finally { input.value=''; } }
  function handleHistoryReset() { if (!window.confirm('Discard the imported history from this browser and restore the synthetic starter dataset?')) return; const rows=createSyntheticHistory();setHistory({rows,source:'synthetic'});setImportStats(null);setTrainingStorageWarning('');setToast('Synthetic starter history restored.'); }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
        <a className="brand" href="#overview" onClick={(event) => { event.preventDefault(); setView('Overview'); }}>
          <span className="brand-mark"><BookOpen size={18} strokeWidth={1.8} /><i /></span>
          <span className="brand-copy"><strong>student<span>insight</span></strong><small>ACADEMIC INTELLIGENCE</small></span>
          <button className="mobile-close icon-button" aria-label="Close navigation" onClick={(event) => { event.preventDefault(); setMobileNav(false); }}><X size={18} /></button>
        </a>
        <div className="nav-label">WORKSPACE</div>
        <nav className="main-nav" aria-label="Main navigation">
          {navItems.map(({ name, icon: Icon }) => <button key={name} className={`nav-link ${view === name ? 'active' : ''}`} onClick={() => { setView(name); setMobileNav(false); }}><Icon size={18} strokeWidth={1.8} /><span>{name}</span>{name === 'Students' && <span className="nav-count">{students.length}</span>}</button>)}
        </nav>
        <div className="nav-label insight-label">MODEL & INSIGHTS</div>
        <div className="term-card"><div className="term-icon"><CalendarDays size={16} /></div><div><span>ACADEMIC TERM</span><strong>Autumn semester</strong><small>Sep — Dec 2026</small></div><ChevronDown size={15} className="term-chevron" /></div>
        <div className="sidebar-bottom">
          <div className="privacy-note"><ShieldCheck size={16} /><span>Records & model data stay local.</span></div>
          <button className="profile"><span className="profile-avatar">MC</span><span className="profile-copy"><strong>Madison Cole</strong><small>Class educator</small></span><MoreHorizontal size={19} /></button>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <button className="icon-button menu-toggle" aria-label="Open navigation" onClick={() => setMobileNav(true)}><Menu size={20} /></button>
          <div className="breadcrumb"><span>Workspace</span><ChevronRight size={14} /><strong>{view}</strong></div>
          <div className="topbar-actions">
            <label className="global-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find a student..." /><kbd>⌘ K</kbd></label>
            <button className="icon-button theme-toggle" title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`} aria-label="Toggle color theme" onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>{theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}</button>
            <button className="icon-button notification-button" aria-label="Notifications"><Bell size={18} /><i /></button>
            <button className="top-avatar" aria-label="User profile">MC</button>
          </div>
        </header>

        <div className="page-wrap">
          {storageWarning && <div className="storage-warning" role="status"><AlertCircle size={15}/>{storageWarning}</div>}
          {view === 'Overview' && <>
            <section className="page-intro intro-overview"><div><div className="eyebrow"><span className="eyebrow-dot" /> AUTUMN SEMESTER <span className="eyebrow-divider">/</span> 2026</div><h1>A clearer picture<br className="mobile-break" /> of every <em>learner.</em></h1><p>Small signals add up. Here’s how your class is finding its rhythm.</p></div><div className="intro-actions"><span className="updated-note"><span className="live-dot" /> All records up to date</span><button className="btn btn-primary" onClick={openCreate}><Plus size={17} /> Add student</button></div></section>
            <section className="metric-grid" aria-label="Class summary">
              <Metric icon={Users} label="Students enrolled" value={String(students.length).padStart(2, '0')} foot="In your active class" accent="teal"/>
              <Metric icon={Activity} label="Average attendance" value={`${averageAttendance}%`} foot={<>Across current records</>} accent="blue"/>
              <Metric icon={BookOpen} label="Average marks" value={`${averageMark}%`} foot={<>Across current records</>} accent="lavender"/>
              <Metric icon={AlertCircle} label="Need a check-in" value={String(atRisk).padStart(2, '0')} foot="A little support could help" accent="amber"/>
            </section>
            <section className="overview-main-grid">
              <article className="panel trend-panel"><div className="panel-head"><div><div className="section-kicker">THE CLASS PICTURE</div><h2>Semester marks movement</h2></div><span className="chart-period"><CalendarDays size={14}/> Previous semester → current</span></div><div className="chart-key"><span><i className="key-dot marks-dot"/>Average marks · current cohort</span></div><div className="trend-chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={trendData} margin={{ top: 12, right: 4, left: -20, bottom: 0 }}><defs><linearGradient id="marksFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#17a58f" stopOpacity={0.18}/><stop offset="90%" stopColor="#17a58f" stopOpacity={0}/></linearGradient><linearGradient id="attendanceFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8399c2" stopOpacity={0.12}/><stop offset="95%" stopColor="#8399c2" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="var(--line-soft)" vertical={false} strokeDasharray="3 5"/><XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fill: 'var(--text-muted)', fontSize: 11 }} dy={9}/><YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fill: 'var(--text-muted)', fontSize: 11 }} tickFormatter={(value) => `${value}%`}/><Tooltip content={<TrendTooltip/>}/><Area type="monotone" dataKey="score" name="Average marks" stroke="#149e89" strokeWidth={2.5} fill="url(#marksFill)" activeDot={{ r: 5, strokeWidth: 0 }}/></AreaChart></ResponsiveContainer></div><div className="chart-footer"><span><span className="footer-dot"/> Actual cohort marks · previous vs current</span><span>Average insight score <strong>{classScore}%</strong></span></div></article>
              <article className="panel distribution-panel"><div className="panel-head"><div><div className="section-kicker">A LITTLE CONTEXT</div><h2>At a glance</h2></div><button className="icon-button small-icon" aria-label="More overview options"><MoreHorizontal size={18}/></button></div><div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={distribution} dataKey="count" nameKey="name" innerRadius="69%" outerRadius="88%" paddingAngle={3} stroke="none" startAngle={90} endAngle={-270}>{distribution.map((entry, index)=><Cell key={entry.name} fill={tones[index]} />)}</Pie><Tooltip content={<DonutTooltip/>}/></PieChart></ResponsiveContainer><div className="donut-center"><strong>{students.length}</strong><span>learners</span></div></div><div className="legend-list">{distribution.map((item,index)=><div key={item.name}><span className="legend-name"><i style={{background: tones[index]}}/>{item.name}</span><strong>{item.count}</strong></div>)}</div><div className="insight-callout"><span className="insight-spark"><Sparkles size={15}/></span><p><strong>Room to rise</strong><br/>{atRisk ? `${atRisk} learner${atRisk === 1 ? '' : 's'} could benefit from a closer check-in.` : 'Your class is finding a strong, steady rhythm.'}</p><ArrowRight size={16}/></div></article>
            </section>
            <section className="panel roster-panel"><div className="panel-head roster-head"><div><div className="section-kicker">YOUR CLASS</div><h2>Student overview <span className="soft-count">{filtered.length}</span></h2></div><button className="text-action" onClick={() => setView('Students')}>View directory <ArrowRight size={15}/></button></div><StudentTable students={filtered.slice(0,5)} onView={setDetail} onEdit={openEdit} onDelete={setDeleteTarget} onSort={handleSort} sortField={sortField} sortDirection={sortDirection} compact/><div className="roster-footer"><span>Showing {Math.min(filtered.length,5)} of {students.length} learners</span><button onClick={() => setView('Students')}>Open full directory <ArrowRight size={14}/></button></div></section>
            <div className="bottom-note"><span><Info size={14}/> Predictions are directional signals to support—not replace—educator judgment.</span><button onClick={() => setView('Model Lab')}>How models work <ArrowRight size={13}/></button></div>
          </>}

          {view === 'Students' && <>
            <section className="page-intro"><div><div className="eyebrow"><span className="eyebrow-dot"/> CLASS DIRECTORY</div><h1>Every learner,<br className="mobile-break"/> in <em>one place.</em></h1><p>Keep student details and progress close at hand.</p></div><div className="intro-actions"><button className="btn btn-secondary" onClick={() => downloadCsv(filtered, modelRun)}><Download size={16}/> Export CSV</button><button className="btn btn-primary" onClick={openCreate}><Plus size={17}/> Add student</button></div></section>
            <section className="directory-toolbar"><div className="directory-title"><div className="toolbar-icon"><Users size={18}/></div><div><strong>Student directory</strong><span>{filtered.length} student{filtered.length === 1 ? '' : 's'} shown</span></div></div><div className="filter-controls"><label className="directory-search"><Search size={15}/><input value={query} onChange={(event)=>setQuery(event.target.value)} placeholder="Search students" aria-label="Search students"/><kbd>⌘ K</kbd></label><div className="filter-select-wrap"><Filter size={14}/><select value={statusFilter} onChange={(event)=>setStatusFilter(event.target.value)} aria-label="Filter by performance"><option>All students</option><option>High-performing</option><option>Average-performing</option><option>At-risk</option></select><ChevronDown size={13}/></div><div className="filter-select-wrap course-select"><select value={courseFilter} onChange={(event)=>setCourseFilter(event.target.value)} aria-label="Filter by course"><option>All courses</option>{courseNames.map((course)=><option key={course}>{course}</option>)}</select><ChevronDown size={13}/></div></div></section>
            <section className="panel directory-panel"><StudentTable students={pageStudents} onView={setDetail} onEdit={openEdit} onDelete={setDeleteTarget} onSort={handleSort} sortField={sortField} sortDirection={sortDirection}/>{filtered.length === 0 && <div className="empty-state"><span><Search size={22}/></span><strong>No students found</strong><p>Try another search or clear your filters.</p><button className="btn btn-secondary" onClick={()=>{setQuery('');setStatusFilter('All students');setCourseFilter('All courses');}}>Clear filters</button></div>}<div className="directory-footer"><span>{filtered.length ? `Showing ${(page - 1) * pageSize + 1}–${Math.min(page * pageSize, filtered.length)} of ${filtered.length} matching student${filtered.length === 1 ? '' : 's'}` : 'No matching records'}</span><div className="pagination"><button disabled={page === 1} onClick={() => setPage((current) => Math.max(1, current - 1))} aria-label="Previous page"><ChevronLeft size={15}/></button><button className="page-number" aria-current="page">{page}</button>{pageCount > 1 && <span className="pagination-total">of {pageCount}</span>}<button disabled={page >= pageCount} onClick={() => setPage((current) => Math.min(pageCount, current + 1))} aria-label="Next page"><ChevronRight size={15}/></button></div></div></section>
            <div className="bottom-note"><span><ShieldCheck size={14}/> Student records are stored in this browser, not uploaded to a server.</span><button onClick={handleReset}><RotateCcw size={13}/> Restore sample data</button></div>
          </>}

          {view === 'Analytics' && <>
            <section className="page-intro"><div><div className="eyebrow"><span className="eyebrow-dot"/> PATTERNS & MOMENTUM</div><h1>Progress has a<br className="mobile-break"/> <em>pattern.</em></h1><p>A few useful signals help turn class data into thoughtful next steps.</p></div><div className="intro-actions"><button className="btn btn-secondary" onClick={()=>void handlePdfExport(students, 'Class analytics report')} disabled={exporting} aria-busy={exporting}><FileDown size={16}/>{exporting ? 'Preparing PDF…' : 'Download report'}</button></div></section>
            <section className="metric-grid analytics-metrics"><Metric icon={TrendingUp} label="Class indicator" value={`${classScore}%`} foot={modelRun.selected.name} accent="teal"/><Metric icon={Activity} label="Attendance average" value={`${averageAttendance}%`} foot="Across the active class" accent="blue"/><Metric icon={BookOpen} label="Marks average" value={`${averageMark}%`} foot="Across all subjects" accent="lavender"/><Metric icon={AlertCircle} label="Potential check-ins" value={String(atRisk)} foot="At risk or need attention" accent="amber"/></section>
            <section className="overview-main-grid analytics-chart-grid"><article className="panel trend-panel"><div className="panel-head"><div><div className="section-kicker">SEMESTER COMPARISON</div><h2>Marks movement</h2></div><span className="chart-period"><span className="live-dot"/> Previous → current semester</span></div><div className="chart-key"><span><i className="key-dot marks-dot"/>Average marks · current cohort</span></div><div className="trend-chart analytics-trend"><ResponsiveContainer width="100%" height="100%"><AreaChart data={trendData} margin={{ top: 12, right: 4, left: -20, bottom: 0 }}><defs><linearGradient id="analyticsMarks" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#17a58f" stopOpacity={0.2}/><stop offset="100%" stopColor="#17a58f" stopOpacity={0}/></linearGradient><linearGradient id="analyticsAttend" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8399c2" stopOpacity={0.12}/><stop offset="100%" stopColor="#8399c2" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="var(--line-soft)" vertical={false} strokeDasharray="3 5"/><XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fill: 'var(--text-muted)', fontSize: 11 }} dy={9}/><YAxis domain={[0,100]} axisLine={false} tickLine={false} tick={{ fill: 'var(--text-muted)', fontSize: 11 }} tickFormatter={(v)=>`${v}%`}/><Tooltip content={<TrendTooltip/>}/><Area type="monotone" dataKey="score" name="Average marks" stroke="#149e89" strokeWidth={2.5} fill="url(#analyticsMarks)"/></AreaChart></ResponsiveContainer></div><div className="chart-footer"><span><span className="footer-dot"/> Actual cohort marks · previous vs current</span><span>Mean indicator <strong>{classScore}%</strong></span></div></article><article className="panel distribution-panel analytics-distribution"><div className="panel-head"><div><div className="section-kicker">CURRENT SNAPSHOT</div><h2>Outcome mix</h2></div></div><div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={distribution} dataKey="count" nameKey="name" innerRadius="69%" outerRadius="88%" paddingAngle={3} stroke="none" startAngle={90} endAngle={-270}>{distribution.map((item,index)=><Cell key={item.name} fill={tones[index]}/>)}</Pie><Tooltip content={<DonutTooltip/>}/></PieChart></ResponsiveContainer><div className="donut-center"><strong>{students.length}</strong><span>learners</span></div></div><div className="legend-list">{distribution.map((item,index)=><div key={item.name}><span className="legend-name"><i style={{background:tones[index]}}/>{item.name}</span><strong>{item.count}</strong></div>)}</div></article></section>
            <section className="panel checkin-panel"><div className="panel-head"><div><div className="section-kicker">A THOUGHTFUL NEXT STEP</div><h2>Consider a check-in</h2></div><span className="quiet-label">Selected-model support signals</span></div>{enriched.filter((student)=>student.prediction.label === 'At-risk').length ? <div className="checkin-list">{enriched.filter((student)=>student.prediction.label === 'At-risk').sort((a,b)=>a.prediction.score-b.prediction.score).slice(0,5).map((student)=><button className="checkin-row" key={student.id} onClick={()=>setDetail(student)}><Avatar student={student}/><span className="checkin-person"><strong>{student.name}</strong><small>{student.course} · {student.attendance}% attendance</small></span><span className={`badge ${predictionTone(student.prediction.label)}`}>{student.prediction.label}</span><span className="checkin-mark">{student.prediction.score}</span><ArrowRight size={16}/></button>)}</div>:<div className="all-well"><CheckCircle2 size={20}/><span>Everyone is currently above the check-in indicator.</span></div>}</section>
            <div className="prediction-note"><span className="prediction-note-icon"><Sparkles size={16}/></span><p><strong>How this indicator works</strong><br/>{modelRun.selected.name} estimates outcomes from all eight academic inputs. Leading model signals include {factorLabels.join(', ')}; these associations are not proof of cause. {evaluationSourceLabel(modelRun)}. {evaluationDisclaimer(modelRun)} Educators—not the model—decide next steps.</p><button onClick={()=>setView('Reports')}>Reporting options <ArrowRight size={14}/></button></div>
          </>}

          {view === 'Model Lab' && <ModelLab rows={history.rows} source={history.source} run={modelRun} stats={importStats} storageWarning={trainingStorageWarning} onUpload={handleHistoryImport} onReset={handleHistoryReset}/>}

          {view === 'Reports' && <>
            <section className="page-intro"><div><div className="eyebrow"><span className="eyebrow-dot"/> READY WHEN YOU ARE</div><h1>Good insights,<br className="mobile-break"/> <em>well shared.</em></h1><p>Take a clear, considered snapshot with you.</p></div><div className="intro-actions"><button className="btn btn-primary" onClick={printAggregate}><Printer size={16}/> Print overview</button></div></section>
            <section className="report-callout"><div className="report-spark"><Sparkles size={20}/></div><div><div className="section-kicker">YOUR CURRENT SNAPSHOT</div><h2>{students.length} learners. One clear picture.</h2><p>Aggregate student details with transparent performance indicators for a simple class report.</p><div className="report-quick-stats"><span><strong>{averageMark}%</strong> average marks</span><i/><span><strong>{averageAttendance}%</strong> average attendance</span><i/><span><strong>{atRisk}</strong> need a check-in</span></div></div><span className="report-watermark"><BarChart3 size={68}/></span></section>
            <section className="report-grid"><ReportCard icon={FileSpreadsheet} number="01" title="Student data · CSV" description="Contact details, all seven academic inputs, selected-model outcomes, and prediction scores." action="Export all students" onClick={()=>downloadCsv(students, modelRun)} tone="green"/><ReportCard icon={FileDown} number="02" title="Performance · PDF" description="Paginated landscape detail with academic indicators, model outcome, and validation context." action={exporting ? 'Preparing PDF…' : 'Download PDF report'} onClick={()=>void handlePdfExport(students)} tone="blue" loading={exporting}/><ReportCard icon={Printer} number="03" title="Print view" description="A clean paper-friendly view with each learner’s progress and performance indicator." action="Open print dialog" onClick={printAggregate} tone="amber"/></section>
            <section className="panel report-preview"><div className="panel-head"><div><div className="section-kicker">REPORT PREVIEW</div><h2>Class performance</h2></div><span className="chart-period">{new Date().toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'})}</span></div><div className="preview-stats"><PreviewStat label="Total students" value={students.length} icon={Users}/><PreviewStat label="Attendance average" value={`${averageAttendance}%`} icon={Activity}/><PreviewStat label="Marks average" value={`${averageMark}%`} icon={BookOpen}/><PreviewStat label="Class indicator" value={`${classScore}%`} icon={TrendingUp}/></div><div className="preview-privacy"><ShieldCheck size={16}/><span>Reports reflect browser-saved student data. Personal information is included in exports.</span></div></section>
          </>}
          <footer className="app-footer"><span>studentinsight <span>·</span> A little more context for every learner.</span><span><span className="footer-live-dot"/> Autosaved on this device</span></footer>
        </div>
      </main>
      <div className="mobile-backdrop" hidden={!mobileNav} onClick={()=>setMobileNav(false)} />

      {formOpen && <Modal title={editing ? 'Edit student record' : 'Add a student'} subtitle={editing ? 'Make a thoughtful update to this learner’s details.' : 'A little more context starts with the basics.'} onClose={()=>setFormOpen(false)} wide><form className="student-form" onSubmit={saveStudent} noValidate><div className="form-section-label">STUDENT DETAILS</div><div className="form-grid"><label className="form-field form-full"><span>Full name</span><div className="input-with-icon"><Users size={16}/><input autoFocus placeholder="e.g. Alex Morgan" value={form.name} onChange={(event)=>setForm({...form,name:event.target.value})}/></div></label><label className="form-field"><span>Email address</span><div className="input-with-icon"><Mail size={16}/><input type="email" placeholder="alex@school.edu" value={form.email} onChange={(event)=>setForm({...form,email:event.target.value})}/></div></label><label className="form-field"><span>Phone number</span><div className="input-with-icon"><Phone size={16}/><input type="tel" placeholder="+1 (555) 000-0000" value={form.phone} onChange={(event)=>setForm({...form,phone:event.target.value})}/></div></label><label className="form-field"><span>Course</span><div className="select-field"><select value={form.course} onChange={(event)=>setForm({...form,course:event.target.value})}><option>Computer Science</option><option>Applied Mathematics</option><option>Data Science</option><option>Design & Technology</option><option>Business Studies</option><option>Other</option></select><ChevronDown size={15}/></div></label><label className="form-field"><span>Academic year</span><div className="select-field"><select value={form.year} onChange={(event)=>setForm({...form,year:event.target.value})}>{['Year 1','Year 2','Year 3','Year 4','Year 5'].map((year)=><option key={year}>{year}</option>)}</select><ChevronDown size={15}/></div></label></div><div className="form-section-label form-performance-label">ACADEMIC MODEL INPUTS <span>Local-only · {modelRun.selected.name}</span></div><div className="form-grid model-input-grid">{modelInputFields.map(({key,label,max,unit,step})=><label className="form-field" key={key}><span>{label}</span><div className="number-input-control"><input className="number-input" type="number" inputMode="decimal" min={0} max={max} step={step} aria-label={label} value={form[key]} onChange={(event)=>setForm({...form,[key]:Number(event.target.value)})}/><span className="number-input-unit" aria-hidden="true">{unit==='%'?'%':'h / wk'}</span></div><small className="number-input-hint">Range: 0–{max}{unit==='%'?'%':' hours per week'}</small></label>)}</div>{formError && <div className="form-error"><AlertCircle size={15}/>{formError}</div>}<div className="form-actions"><span><ShieldCheck size={15}/> Student records stay in this browser</span><div><button type="button" className="btn btn-quiet" onClick={()=>setFormOpen(false)}>Cancel</button><button type="submit" className="btn btn-primary"><Check size={16}/>{editing ? 'Save changes' : 'Add student'}</button></div></div></form></Modal>}

      {detail && <div className="drawer-overlay" onMouseDown={(event)=>{if(event.target===event.currentTarget)setDetail(null);}}><aside className="detail-drawer"><div className="drawer-top"><span>STUDENT PROFILE</span><button className="icon-button" aria-label="Close profile" onClick={()=>setDetail(null)}><X size={19}/></button></div><div className="detail-hero"><Avatar student={detail} large/><span className="detail-id">{detail.id}</span><h2>{detail.name}</h2><p>{detail.course} <i/> {detail.year}</p><span className={`badge ${predictionTone(predictWithModel(detail, modelRun.selected).label)}`}><span className="badge-dot"/>{predictWithModel(detail, modelRun.selected).label}</span></div><div className="detail-score-card"><div><span>INDICATIVE PERFORMANCE</span><strong>{predictWithModel(detail, modelRun.selected).score}<small>/100</small></strong></div><div className="detail-score-ring" style={{'--score':`${predictWithModel(detail, modelRun.selected).score * 3.6}deg`} as React.CSSProperties}><span><Sparkles size={18}/></span></div><p>{predictWithModel(detail, modelRun.selected).note}</p></div><div className="detail-metrics detail-academic-grid"><DetailMetric icon={Activity} label="Attendance" value={`${detail.attendance}%`} color="green"/><DetailMetric icon={BookOpen} label="Current marks" value={`${detail.marks}%`} color="blue"/><DetailMetric icon={BookOpen} label="Internal exam" value={`${detail.internalMarks}%`} color="blue"/><DetailMetric icon={FileSpreadsheet} label="Assignment" value={`${detail.assignmentScore}%`} color="green"/><DetailMetric icon={CheckCircle2} label="Practical" value={`${detail.practicalScore}%`} color="blue"/><DetailMetric icon={CalendarDays} label="Previous semester" value={`${detail.previousSemester}%`} color="green"/><DetailMetric icon={Activity} label="Study / week" value={`${detail.studyHours} h`} color="blue"/><DetailMetric icon={Users} label="Participation" value={`${detail.participation}%`} color="green"/></div><div className="detail-contact"><div className="section-kicker">CONTACT DETAILS</div><div><span><Mail size={15}/></span><p><small>Email address</small><strong>{detail.email}</strong></p></div><div><span><Phone size={15}/></span><p><small>Phone number</small><strong>{detail.phone}</strong></p></div></div><div className="detail-disclaimer"><Info size={15}/><p>{modelRun.selected.name} trained on {history.source === 'synthetic' ? 'synthetic starter examples' : 'your local historical data'}. Advisory only—not a diagnosis or verdict.</p></div><div className="drawer-actions"><button className="btn btn-secondary" onClick={()=>openEdit(detail)}><Pencil size={15}/> Edit profile</button><button className="btn btn-secondary" onClick={()=>printStudentReport(detail)}><Printer size={15}/> Print report</button><button className="icon-button danger-icon" aria-label="Delete student" onClick={()=>setDeleteTarget(detail)}><Trash2 size={17}/></button></div></aside></div>}

      {deleteTarget && <Modal title="Remove this student?" subtitle={`${deleteTarget.name}’s record will be removed from this browser.`} onClose={()=>setDeleteTarget(null)}><div className="delete-dialog"><span><AlertCircle size={22}/></span><p>This cannot be undone. You can export a copy of your class records before removing a student.</p><div className="delete-actions"><button className="btn btn-secondary" onClick={()=>setDeleteTarget(null)}>Keep record</button><button className="btn btn-danger" onClick={confirmDelete}><Trash2 size={15}/> Remove student</button></div></div></Modal>}

      {toast && <div className="toast-message" role="status"><CheckCircle2 size={17}/>{toast}<button aria-label="Dismiss notification" onClick={()=>setToast('')}><X size={15}/></button></div>}

      <AIChat students={students} summary={chatSummary}/>

      <div className="print-report"><h1>AI-Based Student Performance Prediction System</h1><p className="print-subtitle">{printTarget ? `Individual performance report · ${printTarget.name}` : 'Class aggregate performance report'} · {new Date().toLocaleDateString()}</p><div className="print-summary">{printTarget ? <><span><strong>{printTarget.id}</strong> student ID</span><span><strong>{printTarget.attendance}%</strong> attendance</span><span><strong>{printTarget.marks}%</strong> average marks</span><span><strong>{predictWithModel(printTarget,modelRun.selected).score} · {predictWithModel(printTarget,modelRun.selected).label}</strong> indicator</span></> : <><span><strong>{students.length}</strong> students</span><span><strong>{averageAttendance}%</strong> average attendance</span><span><strong>{averageMark}%</strong> average marks</span><span><strong>{classScore}%</strong> class indicator</span></>}</div><table><thead><tr><th>Student</th><th>Contact</th><th>Course</th><th>Attendance</th><th>Marks</th><th>Academic inputs</th><th>Model outcome</th></tr></thead><tbody>{(printTarget ? [printTarget] : students).map((student)=><tr key={student.id}><td>{student.name}<small>{student.id}</small></td><td>{student.email}<small>{student.phone}</small></td><td>{student.course}<small>{student.year}</small></td><td>{student.attendance}%</td><td>{student.marks}%</td><td>Internal {student.internalMarks}% · Assignment {student.assignmentScore}% · Practical {student.practicalScore}% · Previous {student.previousSemester}% · Study {student.studyHours}h/wk · Participation {student.participation}%</td><td>{predictWithModel(student,modelRun.selected).score}% · {predictWithModel(student,modelRun.selected).label}</td></tr>)}</tbody></table><p className="print-disclaimer">Advisory estimate from {modelRun.selected.name}; {evaluationSourceLabel(modelRun)}. {evaluationDisclaimer(modelRun)} Use educator judgment; this prediction is not a diagnosis or automated decision.</p></div>
    </div>
  );
}

function Metric({icon:Icon,label,value,foot,accent}:{icon:typeof Users;label:string;value:string;foot:React.ReactNode;accent:string}) {return <article className="metric-card"><div className={`metric-icon ${accent}`}><Icon size={17}/></div><span className="metric-label">{label}</span><div className="metric-value">{value}</div><div className="metric-foot">{foot}</div><div className="metric-orbit" aria-hidden="true"/></article>}
function Avatar({student,large=false}:{student:Student;large?:boolean}) {const tones=['avatar-sage','avatar-blue','avatar-peach','avatar-lilac','avatar-sand'];const index=(student.name.charCodeAt(0)+student.name.length)%tones.length;return <span className={`student-avatar ${tones[index]} ${large?'avatar-large':''}`}>{initials(student.name)}</span>}
function StudentTable({students,onView,onEdit,onDelete,onSort,sortField,sortDirection,compact=false}:{students:(Student & {prediction:Prediction})[];onView:(student:Student)=>void;onEdit:(student:Student)=>void;onDelete:(student:Student)=>void;onSort:(field:'name'|'attendance'|'marks')=>void;sortField:'name'|'attendance'|'marks';sortDirection:'asc'|'desc';compact?:boolean}) {const icon=(field:'name'|'attendance'|'marks')=>sortField===field?(sortDirection==='asc'?<ArrowUpRight size={13}/>:<ArrowDown size={13}/>):<ArrowDownUp size={12}/>;return <div className={`table-scroll ${compact?'compact-table':''}`}><table className="student-table"><thead><tr><th><button onClick={()=>onSort('name')}>STUDENT {icon('name')}</button></th><th>COURSE</th><th><button onClick={()=>onSort('attendance')}>ATTENDANCE {icon('attendance')}</button></th><th><button onClick={()=>onSort('marks')}>MARKS {icon('marks')}</button></th><th>AI INDICATOR</th><th className="table-actions-head"> </th></tr></thead><tbody>{students.map((student,index)=><tr key={student.id} style={{animationDelay:`${Math.min(index,8)*35}ms`}}><td><button className="student-cell" onClick={()=>onView(student)}><Avatar student={student}/><span><strong>{student.name}</strong><small>{student.email}</small></span></button></td><td><span className="course-name">{student.course}</span><small className="year-label">{student.year}</small></td><td><span className="progress-cell"><span className="progress-track"><i style={{width:`${student.attendance}%`}}/></span><strong>{student.attendance}%</strong></span></td><td><strong className="mark-value">{student.marks}<small>%</small></strong></td><td><span className={`badge ${predictionTone(student.prediction.label)}`}><span className="badge-dot"/>{student.prediction.label}<small className="badge-score">{student.prediction.score}</small></span></td><td><div className="row-actions"><button onClick={()=>onView(student)} title="View student" aria-label={`View ${student.name}`}><Eye size={15}/></button><button onClick={()=>onEdit(student)} title="Edit student" aria-label={`Edit ${student.name}`}><Pencil size={14}/></button><button onClick={()=>onDelete(student)} title="Remove student" aria-label={`Remove ${student.name}`}><Trash2 size={14}/></button></div></td></tr>)}</tbody></table>{students.length===0 && <div className="table-empty"/>}</div>}
function TrendTooltip({active,payload,label}:{active?:boolean;payload?:{name:string;value:number;color:string}[];label?:string}) {if(!active||!payload?.length)return null;return <div className="chart-tooltip"><strong>{label}</strong>{payload.map((item)=><span key={item.name}><i style={{background:item.color}}/>{item.name}<b>{item.value}%</b></span>)}</div>}
function DonutTooltip({active,payload}:{active?:boolean;payload?:{name:string;value:number;payload:{fill:string}}[]}) {if(!active||!payload?.length)return null;return <div className="chart-tooltip"><span><i style={{background:payload[0].payload.fill}}/>{payload[0].name}<b>{payload[0].value}</b></span></div>}
function Modal({title,subtitle,children,onClose,wide=false}:{title:string;subtitle:string;children:React.ReactNode;onClose:()=>void;wide?:boolean}) {useEffect(()=>{const key=(event:KeyboardEvent)=>{if(event.key==='Escape')onClose();};window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key);},[onClose]);return <div className="modal-overlay" onMouseDown={(event)=>{if(event.target===event.currentTarget)onClose();}}><section className={`modal ${wide?'modal-wide':''}`} role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-top"><div><h2 id="modal-title">{title}</h2><p>{subtitle}</p></div><button className="icon-button" aria-label="Close dialog" onClick={onClose}><X size={18}/></button></div>{children}</section></div>}
function DetailMetric({icon:Icon,label,value,color}:{icon:typeof Activity;label:string;value:string;color:string}) {return <div className="detail-metric"><span className={color}><Icon size={16}/></span><small>{label}</small><strong>{value}</strong></div>}
function ReportCard({icon:Icon,number,title,description,action,onClick,tone,loading=false}:{icon:typeof FileDown;number:string;title:string;description:string;action:string;onClick:()=>void;tone:string;loading?:boolean}) {return <article className="report-card"><div className="report-card-head"><span className={`report-card-icon ${tone}`}><Icon size={19}/></span><small>{number}</small></div><h2>{title}</h2><p>{description}</p><button onClick={onClick} disabled={loading} aria-busy={loading}>{action}<ArrowRight size={15}/></button></article>}
function PreviewStat({label,value,icon:Icon}:{label:string;value:string|number;icon:typeof Users}) {return <div className="preview-stat"><span><Icon size={16}/></span><small>{label}</small><strong>{value}</strong></div>}

export default App;
