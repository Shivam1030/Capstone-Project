import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Bot, LockKeyhole, LoaderCircle, MessageCircle, RefreshCw, Send, Sparkles, X } from 'lucide-react';
import type { Student } from '../data/students';
import { redactKnownStudentData } from '../data/privacy';

type ChatMessage = { id: string; role: 'user' | 'assistant'; text: string; retry?: boolean };
export type ChatSummary = {
  studentCount: number; averageAttendance: number; averageMarks: number; averageModelScore: number;
  atRiskCount: number; highPerformingCount: number; averagePerformingCount: number; modelName: string;
  validationMacroF1: number; trainingRowCount: number; datasetSource: 'synthetic' | 'uploaded'; topFactors: string[];
};

export default function AIChat({ students, summary }: { students: Student[]; summary: ChatSummary }) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([{ id: 'hello', role: 'assistant', text: 'I can help you interpret the class patterns and think through supportive next steps. What would you like to explore?' }]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { if (open) { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }); inputRef.current?.focus(); } }, [open, messages, busy]);

  async function sendMessage(value: string, retry = false) {
    const question = value.trim();
    if (!question || busy) return;
    const safeQuestion = redactKnownStudentData(question, students).slice(0, 1800);
    const visibleQuestion = { id: `${Date.now()}-user`, role: 'user' as const, text: safeQuestion };
    const previous = retry ? messages.slice(0, -2) : messages;
    if (!retry) { setMessages((current) => [...current, visibleQuestion]); setInput(''); }
    else setMessages((current) => current.slice(0, -1));
    setBusy(true);
    const conversation = [...previous.filter((item) => !item.retry).slice(-6).map(({ role, text }) => ({ role, content: redactKnownStudentData(text, students).slice(0, 1800) })), { role: 'user' as const, content: safeQuestion }].slice(-8);
    try {
      const response = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: conversation, aggregate: summary }) });
      const payload = await response.json().catch(() => null);
      if (!response.ok) throw new Error(typeof payload?.error === 'string' ? payload.error : 'The assistant could not respond just now.');
      if (typeof payload?.reply !== 'string' || !payload.reply.trim()) throw new Error('The assistant returned an empty answer. Please retry.');
      setMessages((current) => [...current, { id: `${Date.now()}-assistant`, role: 'assistant', text: payload.reply }]);
    } catch (error) {
      setMessages((current) => [...current, { id: `${Date.now()}-error`, role: 'assistant', text: error instanceof Error ? error.message : 'The assistant is temporarily unavailable.', retry: true }]);
      setInput(question);
    } finally { setBusy(false); }
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); void sendMessage(input); }
  return <div className="ai-chat-root">
    {open && <section className="ai-chat-panel" aria-label="AI academic insights assistant">
      <header className="ai-chat-header"><span className="chat-bot-mark"><Bot size={18}/><i/></span><span><strong>Academic insights</strong><small><i/> AI assistant · aggregate context</small></span><button className="chat-close" aria-label="Close assistant" onClick={()=>setOpen(false)}><X size={18}/></button></header>
      <div className="chat-privacy"><LockKeyhole size={13}/><span>Stored student name fragments, email, phone and IDs are scrubbed. Avoid unlisted identifiers; class aggregates reach AI only for cohorts of five or more.</span></div>
      <div className="chat-transcript" ref={scrollRef} aria-live="polite">
        {messages.map((message)=><div className={`chat-message ${message.role==='user'?'user-message':'assistant-message'}`} key={message.id}>{message.role==='assistant' && <span className="chat-message-icon"><Sparkles size={13}/></span>}<div className="chat-bubble">{message.text}{message.retry && <button className="chat-retry" onClick={()=>void sendMessage(input || messages[messages.length - 2]?.text || '',true)}><RefreshCw size={12}/> Try again</button>}</div></div>)}
        {busy && <div className="chat-message assistant-message"><span className="chat-message-icon"><Sparkles size={13}/></span><div className="chat-bubble typing"><LoaderCircle size={14}/> Thinking through the class picture…</div></div>}
      </div>
      {messages.length===1 && <div className="chat-suggestions"><button onClick={()=>void sendMessage('What does the current class pattern suggest?')}>Summarize the class picture</button><button onClick={()=>void sendMessage('What supportive next steps could help students who are at risk?')}>Explore support ideas</button></div>}
      <form className="chat-composer" onSubmit={onSubmit}><input ref={inputRef} value={input} onChange={(event)=>setInput(event.target.value)} placeholder="Ask about class-level insights…" maxLength={1800} aria-label="Message the AI assistant" disabled={busy}/><button aria-label="Send message" type="submit" disabled={busy || !input.trim()}><Send size={15}/></button></form>
      <div className="chat-disclaimer">Guidance only · use educator judgment</div>
    </section>}
    <button className={`chat-launcher ${open?'launcher-open':''}`} onClick={()=>setOpen((value)=>!value)} aria-label={open?'Close AI assistant':'Open AI academic insights assistant'}>{open?<X size={20}/>:<><MessageCircle size={19}/><span>AI assistant</span><i/></>}</button>
  </div>;
}
