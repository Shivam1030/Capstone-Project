import express from 'express';
import { createServer as createHttpServer } from 'node:http';
import { resolve } from 'node:path';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '64kb' }));
const requestWindows = new Map();
const RATE_LIMIT = 12;
const WINDOW_MS = 60_000;

function allowRequest(ip) {
  const now = Date.now();
  const window = requestWindows.get(ip);
  if (!window || now - window.startedAt >= WINDOW_MS) {
    requestWindows.set(ip, { startedAt: now, count: 1 });
    return true;
  }
  if (window.count >= RATE_LIMIT) return false;
  window.count++;
  return true;
}
const cleanup = setInterval(() => {
  const now = Date.now();
  for (const [ip, window] of requestWindows) if (now - window.startedAt > WINDOW_MS * 2) requestWindows.delete(ip);
}, WINDOW_MS);
cleanup.unref();

function safeAggregate(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || !Number.isFinite(value.studentCount) || value.studentCount < 5) return {};
  const safe = {};
  const numericFields = ['studentCount', 'averageAttendance', 'averageMarks', 'averageModelScore', 'atRiskCount', 'highPerformingCount', 'averagePerformingCount', 'validationMacroF1', 'trainingRowCount'];
  for (const field of numericFields) {
    const candidate = value[field];
    if (typeof candidate === 'number' && Number.isFinite(candidate) && candidate >= 0 && candidate <= 100_000) safe[field] = candidate;
  }
  if (['Linear Regression', 'Decision Tree', 'Random Forest', 'Logistic Regression', 'Support Vector Machine'].includes(value.modelName)) safe.modelName = value.modelName;
  if (value.datasetSource === 'synthetic' || value.datasetSource === 'uploaded') safe.datasetSource = value.datasetSource;
  if (value.topFactors && typeof value.topFactors === 'object') {
    const allowed = ['Attendance', 'Current marks', 'Internal exams', 'Assignments', 'Practical work', 'Previous semester', 'Study hours', 'Academic participation'];
    safe.topFactors = Array.isArray(value.topFactors) ? value.topFactors.filter((item) => allowed.includes(item)).slice(0, 4) : [];
  }
  return safe;
}
function removePii(text) {
  return text
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[redacted email]')
    .replace(/\bST[-_ ]?\d{3,}\b/gi, '[redacted student ID]')
    .replace(/\+?\d[\d\s().-]{5,}\d/g, '[redacted phone]')
    .slice(0, 2000);
}

app.get('/_app/health', (_req, res) => res.status(200).json({ ok: true }));
app.post('/api/chat', async (req, res) => {
  if (!allowRequest(req.ip || 'unknown')) return res.status(429).json({ error: 'Please wait a moment before sending another message.' });
  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 8) return res.status(400).json({ error: 'A short conversation is required.' });
  const safeMessages = messages.filter((item) => item && (item.role === 'user' || item.role === 'assistant') && typeof item.content === 'string').map((item) => ({ role: item.role, content: removePii(item.content) }));
  if (!safeMessages.length || !safeMessages.some((item) => item.role === 'user')) return res.status(400).json({ error: 'Ask a question to get started.' });
  if (!process.env.MANUS_API_URL || !process.env.MANUS_API_KEY) return res.status(503).json({ error: 'The secure AI service is not available in this environment yet.' });

  const system = 'You are Student Insight, a supportive academic insights assistant for educators. Give concise, practical, non-judgmental guidance. You receive only anonymized class-level aggregates and possibly synthetic sample data, never student names, IDs, email addresses, phone numbers, or individual records. Do not ask for identifying details, do not invent data or assert causal influence, and do not represent synthetic-demo metrics as institution-specific results. Frame recommendations as prompts for educator review, not diagnoses or consequential decisions. State when evidence is insufficient. The evaluation metrics are held-out validation results, not proof of future performance.';
  const classContext = safeAggregate(req.body?.aggregate);
  const prompt = [{ role: 'system', content: system }, { role: 'user', content: `Anonymized academic summary (aggregate only): ${JSON.stringify(classContext)}\n\nConversation:\n${safeMessages.map((item) => `${item.role}: ${item.content}`).join('\n')}` }];
  try {
    const base = process.env.MANUS_API_URL.replace(/\/+$/, '');
    const response = await fetch(`${base}/v1/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.MANUS_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: prompt, temperature: 0.35 }),
      signal: AbortSignal.timeout(25_000),
    });
    const result = await response.json().catch(() => null);
    if (!response.ok || result?.error) {
      console.error('AI chat upstream request failed with status:', response.status);
      return res.status(502).json({ error: 'The AI assistant could not respond just now. Please retry.' });
    }
    const content = result?.choices?.[0]?.message?.content;
    if (typeof content !== 'string' || !content.trim()) return res.status(502).json({ error: 'The AI assistant returned an empty answer. Please retry.' });
    return res.json({ reply: content.trim().slice(0, 6000) });
  } catch (error) {
    const isTimeout = error?.name === 'TimeoutError' || error?.name === 'AbortError';
    console.error('AI chat request did not complete:', isTimeout ? 'upstream timeout' : 'upstream unavailable');
    return res.status(isTimeout ? 504 : 502).json({ error: isTimeout ? 'The AI assistant took too long to respond. Please retry.' : 'The AI assistant is temporarily unavailable. Please retry.' });
  }
});
app.use('/api', (_req, res) => res.status(404).json({ error: 'API route not found.' }));
const port = Number(process.env.PORT || 3000);
const httpServer = createHttpServer(app);
if (process.env.NODE_ENV === 'production') {
  const dist = resolve(process.cwd(), 'dist');
  app.use(express.static(dist, { index: false }));
  app.get('*', (req, res) => req.path.startsWith('/api/') ? res.status(404).json({ error: 'API route not found.' }) : res.sendFile(resolve(dist, 'index.html')));
  httpServer.listen(port, '0.0.0.0', () => console.log(`Student Insight server listening on ${port}`));
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({ server: { middlewareMode: true, hmr: { server: httpServer } }, appType: 'spa' });
  app.use(vite.middlewares);
  httpServer.listen(port, '0.0.0.0', () => console.log(`Student Insight development server listening on ${port}`));
  const close = async () => { await vite.close(); httpServer.close(); };
  process.once('SIGINT', close); process.once('SIGTERM', close);
}
