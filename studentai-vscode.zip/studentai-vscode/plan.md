# Implementation plan — AI-Based Student Performance Prediction System

## Product scope and behavior

Expand the existing responsive student dashboard into an ML-assisted educational analytics workspace, retaining the requested product title, polished motion, light/dark theme, student directory, CSV/PDF/print reports, and browser-persisted records. Keep original student identity/contact fields (name, email, phone) alongside attendance and marks. Add internal examination, assignment and practical scores, previous-semester results, study hours/pattern indicator, and academic participation. Present all eight academic values as directly editable numeric value boxes—not sliders—with visible unit/range guidance and validation. Provide historical CSV import, data-cleaning feedback, algorithm comparison, student outcome classification, feature-influence explanations, early-support indicators, and a context-aware AI chatbot.

## Data, privacy, and modeling boundaries

This Webdev project now has explicit user approval to enable its managed server capability; the setting is one-way and cannot later be switched off. Turn on `features.server` without enabling the database. Run a small Node/Express server that serves the built client, exposes a same-origin `/api/chat` endpoint, and reads the documented `MANUS_API_URL` and `MANUS_API_KEY` only at runtime. Before an AI request, the client scrubs stored full names, first/last-name fragments (including common near-typed variants), email addresses, phone numbers and student IDs; the backend independently redacts email/phone/ID patterns. Send only the anonymized question and allow-listed aggregate academic indicators. Share current-cohort aggregates with AI only when at least five current student records exist; otherwise allow general chat without student-performance context. Do not persist chat history on the server or log prompts. Enforce request-size and per-IP rate limits, an upstream timeout, and user-visible failure/retry feedback. Retain student profiles, training examples, and model artifacts in browser storage unless a future request explicitly authorizes a shared database.

Historical labeled datasets will be imported locally as CSV and stay in the browser. Parse headers; reject malformed row widths and malformed values; report invalid/missing fields and duplicates; impute explicit missing numeric cells using training-fold medians; reject inputs outside documented valid ranges; normalize numeric features by their domain ranges; and keep labels from leaking into features. The starter cohort is explicitly synthetic and labelled as such. Do not imply it is representative institutional research or a validated model. If an uploaded file lacks the minimum row count or two labeled outcome categories, clearly report that evaluation and live estimates use the synthetic starter fallback, while retaining the original upload in browser storage. Train/test split with a fixed reproducible seed, and show the evaluated sample count and actual evaluation source.

Implement actual, deterministic client-side model candidates for the five named families: Linear Regression (score regression, then documented score-to-category bands), Decision Tree, Random Forest, Logistic Regression, and linear Support Vector Machine. For the classification candidates report held-out accuracy, macro precision/recall/F1, and confusion matrix; for regression report MAE/RMSE and its documented derived-category agreement. Compare results on the same split, identify the chosen model by the configured selection rule, expose feature contribution/importance where the selected model supports it, and generate scores/categories from the selected fitted model. Preserve human review; no automated consequential decision is made. Keep prediction explanations and category boundaries visible.

## Design direction

- **Design Movement:** Editorial data-atelier, combining restrained academic journal typography with a contemporary SaaS analytics cockpit.
- **Core Principles:** Calm information hierarchy; legible, actionable academic metrics; high-trust, accessible contrast; lively but purposeful motion.
- **Color Philosophy:** Ink and warm paper neutrals ground the dashboard, while a luminous teal/cyan accent signals insight and progress. Amber and coral are reserved for attention and at-risk states, never used as decoration alone. Dark mode shifts to deep ink surfaces with softened borders rather than pure black.
- **Layout Paradigm:** A persistent, narrow icon-and-label rail anchors a broad, asymmetric dashboard workspace. Key narrative metrics occupy a top-level overview; charts and action lists align to an editorial column rhythm. The student directory is a full-width operational surface, not a tiny card grid.
- **Signature Elements:** A custom orbit/compass-style student-insight mark; slim gradient score rails with discrete threshold markers; subtle dotted chart/section texture.
- **Interaction Philosophy:** Actions stay close to the data they affect; inline controls and clear confirmations prevent accidental changes. Search/filter state is immediate, forms validate in context, and all feedback is concise and reversible when practical.
- **Animation:** Stagger short (160–280 ms) entrance transitions for summary cards and rows; gently draw chart lines/bars; use small spring-like hover/press feedback for buttons and nav state. Theme changes transition surface and text colors smoothly. Respect `prefers-reduced-motion`; avoid perpetual background movement.
- **Typography System:** Use Inter (or a system sans fallback) for interface and numeric data, paired with a distinctive serif such as DM Serif Display for editorial dashboard headings. Use tabular numerals for metrics. Clear hierarchy: compact uppercase eyebrow, expressive 28–36 px page heading, 20 px section titles, 13–15 px labels/body.
- **Brand Essence:** A clear, student-centered workspace that helps educators spot progress early and act with context. Personality: insightful, composed, supportive.
- **Brand Voice:** Direct, encouraging, nonjudgmental; present predictions as guidance rather than certainty. Examples: “A clearer picture of every learner.” “Watch for momentum—not just averages.”
- **Wordmark & Logo:** A bespoke circular academic compass/orbit combining an open book line with a rising dot-path, paired with a tightly tracked two-line wordmark.
- **Signature Brand Color:** Insight Teal (`#0FAE9A`), supported by indigo and ink neutrals.

## Project structure

- `index.html` — exact requested product title and metadata.
- `src/main.tsx` — bootstrap. `src/App.tsx` — responsive dashboard shell, navigation, analytics charts, student directory/forms/detail dialogs, theme state and report/print workflows.
- `src/data/students.ts` — validated student schema, browser persistence, fictional seed cohort, CSV mapping.
- `src/data/ml/` — CSV parsing and preprocessing, reproducible train/test split, five algorithm implementations, metrics, category mapping, and feature importance.
- `src/data/privacy.ts` — browser-only scrubbing for stored student names, name fragments and contact identifiers before chatbot requests.
- `src/components/ModelLab.tsx`, `src/components/AIChat.tsx` — historical-data model comparison and floating privacy-aware AI assistant; most site layout and record/report interactions remain in `src/App.tsx`.
- `src/styles.css` — theme/design tokens, breakpoints, motion, accessible contrast and print rules.
- `server/index.js` — same-origin API, private Manus LLM proxy, PII redaction and request/rate/time limits, production static serving, health path.
- `Dockerfile` — pinned Node toolchain, dependency install, frontend build and production entrypoint.
- `public/manus-routes.json` — single-page route manifest (client view switching remains on `/`).
- `plan.md`, `TODO.md` — approved scope and tracked product outcomes.

## Serving and deployment

Maintain the existing runtime port 3000. Use an Express server wrapping Vite middleware for Cloud Preview so `/api/chat` and the client share one origin; use Express plus `dist/` for production. Enable the managed server resource only (no database). Retain the existing npm lock and pin. Declare both hybrid static build output (`dist`) and a Node container with an unauthenticated health route; publish routing sends `/api/*` to the server and static application requests to the built site. The server is used for the AI proxy only; browser records/history and ML training stay local.
